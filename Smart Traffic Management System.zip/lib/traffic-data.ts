// Real AI Model Integration Framework
// This file simulates YOLO v8, CNN, and LSTM model outputs
// In production, replace these functions with actual API calls to your AI models

export interface TrafficLight {
  id: string
  location: string
  lat: number
  lng: number
  status: "green" | "yellow" | "red"
  duration: number
  aiControlled: boolean
  lastUpdated: Date
  confidence: number // AI confidence in decision
}

export interface VehicleDetection {
  id: string
  type: "car" | "truck" | "motorcycle" | "bus" | "bicycle" | "pedestrian"
  confidence: number // YOLO detection confidence
  boundingBox: { x: number; y: number; width: number; height: number }
  speed: number // km/h
  direction: number // degrees
  lane: number
  timestamp: Date
  cameraId: string
}

export interface CongestionZone {
  id: string
  location: string
  lat: number
  lng: number
  level: "free" | "moderate" | "heavy" | "severe"
  vehicleCount: number
  avgSpeed: number
  timestamp: Date
  predictedDuration: number // minutes
  confidence: number // LSTM prediction confidence
}

export interface AIDecision {
  id: string
  timestamp: Date
  type: "traffic_light" | "congestion_alert" | "route_optimization" | "incident_detection"
  description: string
  confidence: number
  location: string
  modelUsed: "YOLO" | "CNN" | "LSTM" | "Hybrid"
  actionTaken: string
}

export interface CameraFeed {
  id: string
  location: string
  lat: number
  lng: number
  status: "online" | "offline" | "maintenance"
  fps: number
  resolution: string
  lastFrame: Date
  vehiclesDetected: number
  streamUrl: string // In production, this would be the real camera stream URL
}

// Durban traffic lights with realistic data
export const trafficLights: TrafficLight[] = [
  {
    id: "TL001",
    location: "M4 & Brickfield Rd",
    lat: -29.8587,
    lng: 31.0218,
    status: "green",
    duration: 45,
    aiControlled: true,
    lastUpdated: new Date(),
    confidence: 0.94,
  },
  {
    id: "TL002",
    location: "N2 & Umgeni Rd",
    lat: -29.8487,
    lng: 31.0118,
    status: "red",
    duration: 30,
    aiControlled: true,
    lastUpdated: new Date(),
    confidence: 0.91,
  },
  {
    id: "TL003",
    location: "M19 & Sarnia Rd",
    lat: -29.8687,
    lng: 31.0318,
    status: "green",
    duration: 60,
    aiControlled: true,
    lastUpdated: new Date(),
    confidence: 0.88,
  },
  {
    id: "TL004",
    location: "M4 & Point Rd",
    lat: -29.8787,
    lng: 31.0418,
    status: "yellow",
    duration: 5,
    aiControlled: false,
    lastUpdated: new Date(),
    confidence: 0.0,
  },
]

// Camera feeds with realistic metadata
export const cameraFeeds: CameraFeed[] = [
  {
    id: "CAM001",
    location: "M4 Highway North",
    lat: -29.8587,
    lng: 31.0218,
    status: "online",
    fps: 30,
    resolution: "1920x1080",
    lastFrame: new Date(),
    vehiclesDetected: 0,
    streamUrl: "/api/camera/stream/CAM001", // Placeholder for real stream
  },
  {
    id: "CAM002",
    location: "N2 Freeway",
    lat: -29.8487,
    lng: 31.0118,
    status: "online",
    fps: 30,
    resolution: "1920x1080",
    lastFrame: new Date(),
    vehiclesDetected: 0,
    streamUrl: "/api/camera/stream/CAM002",
  },
  {
    id: "CAM003",
    location: "M19 Highway",
    lat: -29.8687,
    lng: 31.0318,
    status: "online",
    fps: 30,
    resolution: "1920x1080",
    lastFrame: new Date(),
    vehiclesDetected: 0,
    streamUrl: "/api/camera/stream/CAM003",
  },
  {
    id: "CAM004",
    location: "Point Road",
    lat: -29.8787,
    lng: 31.0418,
    status: "online",
    fps: 30,
    resolution: "1920x1080",
    lastFrame: new Date(),
    vehiclesDetected: 0,
    streamUrl: "/api/camera/stream/CAM004",
  },
]

// Simulate YOLO v8 vehicle detection
// In production: Replace with actual YOLO API call
export function detectVehiclesYOLO(cameraId: string): VehicleDetection[] {
  const detections: VehicleDetection[] = []
  const vehicleTypes: Array<"car" | "truck" | "motorcycle" | "bus" | "bicycle"> = [
    "car",
    "truck",
    "motorcycle",
    "bus",
    "bicycle",
  ]

  // Simulate realistic traffic patterns based on time of day
  const hour = new Date().getHours()
  const isPeakHour = (hour >= 7 && hour <= 9) || (hour >= 16 && hour <= 18)
  const baseVehicleCount = isPeakHour ? 25 : 12
  const vehicleCount = Math.floor(Math.random() * 10) + baseVehicleCount

  for (let i = 0; i < vehicleCount; i++) {
    const type = vehicleTypes[Math.floor(Math.random() * vehicleTypes.length)]
    // Higher confidence for cars, lower for motorcycles (realistic YOLO behavior)
    const baseConfidence = type === "car" ? 0.95 : type === "truck" ? 0.92 : type === "bus" ? 0.9 : 0.85
    const confidence = baseConfidence - Math.random() * 0.1

    detections.push({
      id: `VEH_${cameraId}_${Date.now()}_${i}`,
      type,
      confidence,
      boundingBox: {
        x: Math.random() * 1920,
        y: Math.random() * 1080,
        width: type === "truck" || type === "bus" ? 200 + Math.random() * 100 : 120 + Math.random() * 80,
        height: type === "truck" || type === "bus" ? 150 + Math.random() * 50 : 80 + Math.random() * 40,
      },
      speed: isPeakHour ? 20 + Math.random() * 30 : 50 + Math.random() * 40,
      direction: Math.random() * 360,
      lane: Math.floor(Math.random() * 3) + 1,
      timestamp: new Date(),
      cameraId,
    })
  }

  return detections
}

// Simulate CNN vehicle classification
// In production: Replace with actual CNN model API
export function classifyVehiclesCNN(detections: VehicleDetection[]) {
  return detections.map((detection) => ({
    ...detection,
    // CNN adds additional classification details
    subType:
      detection.type === "car"
        ? ["sedan", "suv", "hatchback"][Math.floor(Math.random() * 3)]
        : detection.type === "truck"
          ? ["pickup", "delivery", "heavy"][Math.floor(Math.random() * 3)]
          : "standard",
    color: ["white", "black", "silver", "red", "blue"][Math.floor(Math.random() * 5)],
    make: ["Toyota", "Honda", "Ford", "Nissan", "BMW"][Math.floor(Math.random() * 5)],
  }))
}

// Simulate LSTM traffic prediction
// In production: Replace with actual LSTM model API
export function predictTrafficLSTM(historicalData: any[]): CongestionZone[] {
  const zones: CongestionZone[] = []
  const locations = [
    { name: "M4 Highway North", lat: -29.8587, lng: 31.0218 },
    { name: "N2 Freeway", lat: -29.8487, lng: 31.0118 },
    { name: "M19 Highway", lat: -29.8687, lng: 31.0318 },
    { name: "Point Road", lat: -29.8787, lng: 31.0418 },
  ]

  const hour = new Date().getHours()
  const isPeakHour = (hour >= 7 && hour <= 9) || (hour >= 16 && hour <= 18)

  locations.forEach((loc, index) => {
    // LSTM predicts congestion based on patterns
    const baseCongestion = isPeakHour ? 0.7 : 0.3
    const congestionProbability = baseCongestion + (Math.random() - 0.5) * 0.3

    let level: "free" | "moderate" | "heavy" | "severe"
    let vehicleCount: number
    let avgSpeed: number

    if (congestionProbability > 0.8) {
      level = "severe"
      vehicleCount = 280 + Math.floor(Math.random() * 50)
      avgSpeed = 10 + Math.random() * 10
    } else if (congestionProbability > 0.6) {
      level = "heavy"
      vehicleCount = 200 + Math.floor(Math.random() * 80)
      avgSpeed = 20 + Math.random() * 15
    } else if (congestionProbability > 0.4) {
      level = "moderate"
      vehicleCount = 120 + Math.floor(Math.random() * 80)
      avgSpeed = 40 + Math.random() * 20
    } else {
      level = "free"
      vehicleCount = 50 + Math.floor(Math.random() * 50)
      avgSpeed = 60 + Math.random() * 20
    }

    zones.push({
      id: `CZ00${index + 1}`,
      location: loc.name,
      lat: loc.lat,
      lng: loc.lng,
      level,
      vehicleCount,
      avgSpeed: Math.round(avgSpeed),
      timestamp: new Date(),
      predictedDuration: level === "severe" ? 45 : level === "heavy" ? 25 : level === "moderate" ? 10 : 0,
      confidence: 0.82 + Math.random() * 0.15, // LSTM confidence
    })
  })

  return zones
}

// Generate real-time traffic flow data based on actual patterns
export function generateTrafficFlowData(hours = 24) {
  const data = []
  const now = Date.now()

  for (let i = hours; i >= 0; i--) {
    const timestamp = new Date(now - i * 3600000)
    const hour = timestamp.getHours()

    // Realistic traffic patterns: peak hours have more vehicles, slower speeds
    const isPeakHour = (hour >= 7 && hour <= 9) || (hour >= 16 && hour <= 18)
    const isNightTime = hour >= 22 || hour <= 5

    let baseVehicles: number
    let baseSpeed: number
    let baseCongestion: number

    if (isPeakHour) {
      baseVehicles = 250
      baseSpeed = 25
      baseCongestion = 75
    } else if (isNightTime) {
      baseVehicles = 80
      baseSpeed = 70
      baseCongestion = 15
    } else {
      baseVehicles = 150
      baseSpeed = 50
      baseCongestion = 40
    }

    data.push({
      time: timestamp.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" }),
      vehicles: Math.floor(baseVehicles + (Math.random() - 0.5) * 50),
      avgSpeed: Math.floor(baseSpeed + (Math.random() - 0.5) * 15),
      congestionLevel: Math.floor(baseCongestion + (Math.random() - 0.5) * 20),
    })
  }

  return data
}

// Generate vehicle detection summary from all cameras
export function generateVehicleDetectionData() {
  let totalCars = 0
  let totalTrucks = 0
  let totalMotorcycles = 0
  let totalBuses = 0

  // Aggregate detections from all cameras
  cameraFeeds.forEach((camera) => {
    if (camera.status === "online") {
      const detections = detectVehiclesYOLO(camera.id)
      detections.forEach((detection) => {
        if (detection.type === "car") totalCars++
        else if (detection.type === "truck") totalTrucks++
        else if (detection.type === "motorcycle") totalMotorcycles++
        else if (detection.type === "bus") totalBuses++
      })
    }
  })

  return {
    cars: totalCars,
    trucks: totalTrucks,
    motorcycles: totalMotorcycles,
    buses: totalBuses,
    timestamp: new Date(),
    totalDetected: totalCars + totalTrucks + totalMotorcycles + totalBuses,
  }
}

// AI decision log with realistic model outputs
export const aiDecisions: AIDecision[] = [
  {
    id: "AD001",
    timestamp: new Date(Date.now() - 120000),
    type: "traffic_light",
    description:
      "Extended green light duration at M4 & Brickfield Rd by 15 seconds due to heavy traffic detected by YOLO",
    confidence: 0.92,
    location: "M4 & Brickfield Rd",
    modelUsed: "YOLO",
    actionTaken: "Increased green phase duration",
  },
  {
    id: "AD002",
    timestamp: new Date(Date.now() - 300000),
    type: "congestion_alert",
    description: "LSTM predicted heavy congestion on M4 Highway North in next 30 minutes. Estimated delay: 7 minutes",
    confidence: 0.88,
    location: "M4 Highway North",
    modelUsed: "LSTM",
    actionTaken: "Sent alert to users",
  },
  {
    id: "AD003",
    timestamp: new Date(Date.now() - 480000),
    type: "route_optimization",
    description: "CNN analysis shows alternate route via M19 is 12% faster. Recommended to users.",
    confidence: 0.85,
    location: "N2 Freeway",
    modelUsed: "CNN",
    actionTaken: "Updated route recommendations",
  },
  {
    id: "AD004",
    timestamp: new Date(Date.now() - 600000),
    type: "incident_detection",
    description: "YOLO detected stopped vehicle on N2 Freeway. Possible accident or breakdown.",
    confidence: 0.9,
    location: "N2 & Umgeni Rd",
    modelUsed: "YOLO",
    actionTaken: "Alerted traffic control center",
  },
]

// Simulate congestion prediction for next 6 hours using LSTM
export function predictCongestion(currentData: any) {
  const predictions = []
  const locations = ["M4 Highway", "N2 Freeway", "M19 Highway", "Point Road"]
  const currentHour = new Date().getHours()

  for (let i = 1; i <= 6; i++) {
    const futureHour = (currentHour + i) % 24
    const isPeakHour = (futureHour >= 7 && futureHour <= 9) || (futureHour >= 16 && futureHour <= 18)

    // LSTM predicts higher probability during peak hours
    const baseProbability = isPeakHour ? 75 : 35
    const probability = baseProbability + (Math.random() - 0.5) * 20

    predictions.push({
      hour: i,
      location: locations[Math.floor(Math.random() * locations.length)],
      probability: Math.max(0, Math.min(100, probability)),
      severity: probability > 70 ? "High" : probability > 50 ? "Medium" : "Low",
      confidence: 0.8 + Math.random() * 0.15, // LSTM model confidence
    })
  }

  return predictions
}

// Export congestion zones with LSTM predictions
export const congestionZones = predictTrafficLSTM([])

// API Integration Points (for production)
// Uncomment and implement these when connecting to real AI models

/*
export async function fetchRealYOLODetections(cameraId: string): Promise<VehicleDetection[]> {
  const response = await fetch(`/api/ai/yolo/detect?camera=${cameraId}`)
  return response.json()
}

export async function fetchRealCNNClassification(detections: VehicleDetection[]) {
  const response = await fetch('/api/ai/cnn/classify', {
    method: 'POST',
    body: JSON.stringify({ detections })
  })
  return response.json()
}

export async function fetchRealLSTMPrediction(historicalData: any[]): Promise<CongestionZone[]> {
  const response = await fetch('/api/ai/lstm/predict', {
    method: 'POST',
    body: JSON.stringify({ data: historicalData })
  })
  return response.json()
}

export async function fetchRealCameraStream(cameraId: string): Promise<string> {
  const response = await fetch(`/api/camera/stream/${cameraId}`)
  const data = await response.json()
  return data.streamUrl
}
*/

export function calculateDistance(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 6371 // Earth's radius in km
  const dLat = ((lat2 - lat1) * Math.PI) / 180
  const dLng = ((lng2 - lng1) * Math.PI) / 180
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLng / 2) * Math.sin(dLng / 2)
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
  return R * c // Distance in km
}

export function getNearbyTrafficLights(userLat: number, userLng: number, radiusKm = 5): TrafficLight[] {
  return trafficLights.filter((light) => {
    const distance = calculateDistance(userLat, userLng, light.lat, light.lng)
    return distance <= radiusKm
  })
}
