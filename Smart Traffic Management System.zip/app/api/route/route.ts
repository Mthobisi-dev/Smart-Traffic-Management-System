import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { start, end } = await request.json()

    if (!start || !end || !start.lat || !start.lng || !end.lat || !end.lng) {
      return NextResponse.json({ error: "Invalid coordinates" }, { status: 400 })
    }

    const apiKey =
      "eyJvcmciOiI1YjNjZTM1OTc4NTExMTAwMDFjZjYyNDgiLCJpZCI6IjM0OGM4YWU2NDJmNjk0YmRlYjRmZWZlZDgzZTI2Y2VhYjAwOTYwZTI3MTMxYzEzZjA1NTRmOGRhIiwiaCI6Im11cm11cjY0In0="

    console.log("[v0] Calculating route from", start, "to", end)

    const response = await fetch("https://api.openrouteservice.org/v2/directions/driving-car/geojson", {
      method: "POST",
      headers: {
        Accept: "application/json, application/geo+json, application/gpx+xml, img/png; charset=utf-8",
        "Content-Type": "application/json",
        Authorization: apiKey,
      },
      body: JSON.stringify({
        coordinates: [
          [start.lng, start.lat],
          [end.lng, end.lat],
        ],
        instructions: true,
        units: "m",
      }),
    })

    if (!response.ok) {
      const errorText = await response.text()
      console.error("[v0] ORS API error:", response.status, errorText)
      return NextResponse.json({ error: `OpenRouteService API error: ${response.status}` }, { status: response.status })
    }

    const data = await response.json()
    console.log("[v0] Route calculated successfully")
    return NextResponse.json(data)
  } catch (error) {
    console.error("[v0] Route API error:", error)
    return NextResponse.json({ error: "Failed to calculate route" }, { status: 500 })
  }
}
