import type React from "react"
import type { Metadata } from "next"
import { Geist, Geist_Mono } from "next/font/google"
import "./globals.css"

const _geist = Geist({ subsets: ["latin"] })
const _geistMono = Geist_Mono({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "AI Traffic Management System - Durban",
  description: "Smart traffic monitoring and optimization using AI, GPS, and camera analysis for Durban, South Africa",
  generator: "v0.app",
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className="dark">
      <head>
        <script
          dangerouslySetInnerHTML={{
            __html: `
              // Suppress MetaMask and wallet extension errors
              window.addEventListener('unhandledrejection', function(event) {
                const error = event.reason;
                const errorMsg = error?.message || error?.toString() || '';
                
                // Check for MetaMask, wallet, or web3 related errors
                if (
                  errorMsg.includes('MetaMask') ||
                  errorMsg.includes('metamask') ||
                  errorMsg.includes('ethereum') ||
                  errorMsg.includes('web3') ||
                  errorMsg.includes('wallet') ||
                  errorMsg.includes('Failed to connect')
                ) {
                  event.preventDefault();
                  event.stopPropagation();
                  event.stopImmediatePropagation();
                  return false;
                }
              }, true);
              
              // Block wallet extensions from injecting
              Object.defineProperty(window, 'ethereum', {
                get: function() { return undefined; },
                set: function() {},
                configurable: false
              });
              
              Object.defineProperty(window, 'web3', {
                get: function() { return undefined; },
                set: function() {},
                configurable: false
              });
            `,
          }}
        />
      </head>
      <body className={`font-sans antialiased`}>{children}</body>
    </html>
  )
}
