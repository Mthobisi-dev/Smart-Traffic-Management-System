import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Activity, MapPin, Camera, Zap, UserPlus, ShieldPlus } from "lucide-react"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-primary/5 to-accent/10">
      <div className="container mx-auto px-4 py-16">
        <div className="text-center mb-16">
          <h1 className="text-5xl font-bold mb-4 bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
            AI-Powered Smart Traffic Management
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Intelligent traffic monitoring and optimization for Durban, South Africa using advanced AI algorithms
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          <Card className="border-primary/20 hover:border-primary/40 transition-colors">
            <CardHeader>
              <MapPin className="h-10 w-10 text-primary mb-2" />
              <CardTitle>Real-time GPS Tracking</CardTitle>
              <CardDescription>Live vehicle tracking and congestion detection across Durban</CardDescription>
            </CardHeader>
          </Card>

          <Card className="border-accent/20 hover:border-accent/40 transition-colors">
            <CardHeader>
              <Camera className="h-10 w-10 text-accent mb-2" />
              <CardTitle>AI Camera Analysis</CardTitle>
              <CardDescription>YOLO, CNN, LSTM algorithms for vehicle detection and counting</CardDescription>
            </CardHeader>
          </Card>

          <Card className="border-chart-3/20 hover:border-chart-3/40 transition-colors">
            <CardHeader>
              <Zap className="h-10 w-10 text-chart-3 mb-2" />
              <CardTitle>Smart Traffic Lights</CardTitle>
              <CardDescription>AI-controlled traffic signals based on real-time data</CardDescription>
            </CardHeader>
          </Card>

          <Card className="border-chart-4/20 hover:border-chart-4/40 transition-colors">
            <CardHeader>
              <Activity className="h-10 w-10 text-chart-4 mb-2" />
              <CardTitle>Predictive Analytics</CardTitle>
              <CardDescription>Machine learning models predict traffic patterns and congestion</CardDescription>
            </CardHeader>
          </Card>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-4">
          <Link href="/admin/login">
            <Button size="lg" className="w-full sm:w-auto">
              Admin Login
            </Button>
          </Link>
          <Link href="/user/login">
            <Button size="lg" variant="outline" className="w-full sm:w-auto bg-transparent">
              User Login
            </Button>
          </Link>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <Link href="/admin/register">
            <Button size="lg" variant="secondary" className="w-full sm:w-auto">
              <ShieldPlus className="mr-2 h-4 w-4" />
              Register as Admin
            </Button>
          </Link>
          <Link href="/user/register">
            <Button size="lg" variant="secondary" className="w-full sm:w-auto">
              <UserPlus className="mr-2 h-4 w-4" />
              Register as User
            </Button>
          </Link>
        </div>

        <div className="mt-16 grid md:grid-cols-2 gap-6">
          <div className="p-6 bg-card rounded-lg border border-border">
            <h2 className="text-2xl font-bold mb-4">Demo Admin Credentials</h2>
            <div className="grid gap-4 font-mono text-sm">
              <div>
                <p className="text-muted-foreground">Email:</p>
                <p className="font-semibold">admin@durban-traffic.za</p>
              </div>
              <div>
                <p className="text-muted-foreground">Password:</p>
                <p className="font-semibold">Admin@2024</p>
              </div>
            </div>
          </div>

          <div className="p-6 bg-card rounded-lg border border-border">
            <h2 className="text-2xl font-bold mb-4">Demo User Credentials</h2>
            <div className="grid gap-4 font-mono text-sm">
              <div>
                <p className="text-muted-foreground">Email:</p>
                <p className="font-semibold">user@durban-traffic.za</p>
              </div>
              <div>
                <p className="text-muted-foreground">Password:</p>
                <p className="font-semibold">User@2024</p>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-8 text-center">
          <p className="text-xs text-muted-foreground">Made by Mthobis Mzimela</p>
        </div>
      </div>
    </div>
  )
}
