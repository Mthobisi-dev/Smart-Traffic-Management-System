"use client"

import type React from "react"
import { useEffect, useState, useRef } from "react"
import { useRouter } from "next/navigation"
import Script from "next/script"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  MapPin,
  AlertTriangle,
  Camera,
  Upload,
  FileVideo,
  LogOut,
  Crosshair,
  Bell,
  Volume2,
  VolumeX,
  Navigation,
  X,
  RefreshCw,
  Moon,
  Sun,
  MapPinned,
} from "lucide-react"
import { calculateDistance, announceNavigation } from "@/utils/navigationUtils"

declare global {
  interface Window {
    L: any
  }
}

interface Alert {
  id: string
  type: "ai" | "admin"
  title: string
  message: string
  timestamp: Date
  priority: "low" | "medium" | "high"
  read: boolean
}

interface RouteStep {
  instruction: string
  distance: number
  duration: number
  type: number
  name: string
}

export default function UserDashboard() {
  const router = useRouter()
  const mapRef = useRef<HTMLDivElement>(null)
  const mapInstanceRef = useRef<any>(null)
  const markerRef = useRef<any>(null)
  const accuracyCircleRef = useRef<any>(null)
  const watchIdRef = useRef<number | null>(null)
  const [mapLoaded, setMapLoaded] = useState(false)
  const [authenticated, setAuthenticated] = useState(false)
  const [leafletLoaded, setLeafletLoaded] = useState(false)

  const [currentLocation, setCurrentLocation] = useState({ lat: -29.8587, lng: 31.0218 })
  const [gpsAccuracy, setGpsAccuracy] = useState(0)
  const [gpsStatus, setGpsStatus] = useState<"searching" | "active" | "error">("searching")
  const [currentSpeed, setCurrentSpeed] = useState(0)
  const [heading, setHeading] = useState(0)

  const [reportDialogOpen, setReportDialogOpen] = useState(false)
  const [problemDescription, setProblemDescription] = useState("")
  const [problemLocation, setProblemLocation] = useState("")
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([])

  const [alerts, setAlerts] = useState<Alert[]>([])
  const [voiceEnabled, setVoiceEnabled] = useState(true)
  const [unreadCount, setUnreadCount] = useState(0)
  const lastAlertCheckRef = useRef<string>("")
  const voiceEnabledRef = useRef(voiceEnabled)

  const [navigationActive, setNavigationActive] = useState(false)
  const [destination, setDestination] = useState("")
  const [destinationCoords, setDestinationCoords] = useState<{ lat: number; lng: number } | null>(null)
  const [routePolyline, setRoutePolyline] = useState<any>(null)
  const [destinationMarker, setDestinationMarker] = useState<any>(null)
  const [navigationVoiceEnabled, setNavigationVoiceEnabled] = useState(true)
  const [currentInstruction, setCurrentInstruction] = useState("")
  const [distanceToDestination, setDistanceToDestination] = useState(0)
  const [estimatedTime, setEstimatedTime] = useState(0)
  const [routeSteps, setRouteSteps] = useState<RouteStep[]>([])
  const [currentStepIndex, setCurrentStepIndex] = useState(0)
  const [totalDistance, setTotalDistance] = useState(0)
  const [totalDuration, setTotalDuration] = useState(0)
  const [isCalculatingRoute, setIsCalculatingRoute] = useState(false)
  const [darkMode, setDarkMode] = useState(false)
  const [clickToSetDestination, setClickToSetDestination] = useState(false)
  const lastAnnouncedStepRef = useRef(-1)

  useEffect(() => {
    const userAuth = localStorage.getItem("userAuth")
    if (userAuth !== "true") {
      router.push("/user/login")
    } else {
      setAuthenticated(true)
    }
  }, [router])

  const handleLogout = () => {
    localStorage.removeItem("userAuth")
    localStorage.removeItem("userEmail")
    router.push("/")
  }

  useEffect(() => {
    if (!authenticated) return

    const checkForAlerts = () => {
      const adminAlerts = JSON.parse(localStorage.getItem("userAlerts") || "[]")
      const aiAlerts = generateAIAlerts()
      const allAlerts = [...adminAlerts, ...aiAlerts]

      const alertIds = allAlerts.map((a: Alert) => a.id).join(",")
      if (alertIds !== lastAlertCheckRef.current) {
        const newAlerts = allAlerts.filter((a: Alert) => !lastAlertCheckRef.current.includes(a.id))

        if (voiceEnabledRef.current && newAlerts.length > 0) {
          console.log("[v0] Announcing", newAlerts.length, "new alerts (voice enabled)")
          newAlerts.forEach((alert: Alert) => {
            announceAlert(alert)
          })
        } else if (!voiceEnabledRef.current && newAlerts.length > 0) {
          console.log("[v0] Skipping", newAlerts.length, "alerts (voice disabled)")
        }

        lastAlertCheckRef.current = alertIds
      }

      setAlerts(allAlerts)
      setUnreadCount(allAlerts.filter((a: Alert) => !a.read).length)
    }

    checkForAlerts()
    const interval = setInterval(checkForAlerts, 5000)

    return () => clearInterval(interval)
  }, [authenticated])

  useEffect(() => {
    voiceEnabledRef.current = voiceEnabled
    console.log("[v0] Voice alerts", voiceEnabled ? "enabled" : "disabled")
  }, [voiceEnabled])

  const generateAIAlerts = (): Alert[] => {
    const aiAlerts: Alert[] = []
    const now = new Date()

    if (Math.random() > 0.7) {
      aiAlerts.push({
        id: `ai-${Date.now()}-traffic`,
        type: "ai",
        title: "Heavy Traffic Detected",
        message: "AI detected heavy traffic on M4 Highway North. Consider alternate route via M19.",
        timestamp: now,
        priority: "high",
        read: false,
      })
    }

    if (Math.random() > 0.85) {
      aiAlerts.push({
        id: `ai-${Date.now()}-accident`,
        type: "ai",
        title: "Incident Alert",
        message: "AI detected possible accident on N2 Freeway near Umgeni Rd. Expect delays.",
        timestamp: now,
        priority: "high",
        read: false,
      })
    }

    if (Math.random() > 0.8) {
      aiAlerts.push({
        id: `ai-${Date.now()}-optimization`,
        type: "ai",
        title: "Route Optimization",
        message: "AI optimized traffic lights on your route. Estimated time saved: 3 minutes.",
        timestamp: now,
        priority: "low",
        read: false,
      })
    }

    return aiAlerts
  }

  const announceAlert = (alert: Alert) => {
    if ("speechSynthesis" in window) {
      const utterance = new SpeechSynthesisUtterance(
        `${alert.priority === "high" ? "Urgent alert. " : ""}${alert.title}. ${alert.message}`,
      )
      utterance.rate = 0.9
      utterance.pitch = 1
      utterance.volume = 1

      window.speechSynthesis.cancel()
      window.speechSynthesis.speak(utterance)

      console.log("[v0] Voice alert announced:", alert.title)
    }
  }

  const markAlertAsRead = (alertId: string) => {
    setAlerts((prev) => prev.map((a) => (a.id === alertId ? { ...a, read: true } : a)))

    const adminAlerts = JSON.parse(localStorage.getItem("userAlerts") || "[]")
    const updatedAdminAlerts = adminAlerts.map((a: Alert) => (a.id === alertId ? { ...a, read: true } : a))
    localStorage.setItem("userAlerts", JSON.stringify(updatedAdminAlerts))
  }

  const clearAllAlerts = () => {
    setAlerts([])
    localStorage.setItem("userAlerts", "[]")
    setUnreadCount(0)
  }

  useEffect(() => {
    if (!authenticated) return

    if ("geolocation" in navigator) {
      const watchId = navigator.geolocation.watchPosition(
        (position) => {
          const { latitude, longitude, accuracy, speed, heading } = position.coords
          setCurrentLocation({ lat: latitude, lng: longitude })
          setGpsAccuracy(accuracy)
          setGpsStatus("active")

          if (speed !== null) {
            setCurrentSpeed(Math.round(speed * 3.6))
          }

          if (heading !== null) {
            setHeading(Math.round(heading))
          }
        },
        (error) => {
          if (error.code === error.TIMEOUT) {
            setGpsStatus("searching")
          } else if (error.code === error.PERMISSION_DENIED) {
            setGpsStatus("error")
          } else {
            setGpsStatus("error")
          }
          setCurrentLocation({ lat: -29.8587, lng: 31.0218 })
        },
        {
          enableHighAccuracy: true,
          timeout: 30000,
          maximumAge: 10000,
        },
      )

      watchIdRef.current = watchId

      return () => {
        if (watchIdRef.current !== null) {
          navigator.geolocation.clearWatch(watchIdRef.current)
        }
      }
    } else {
      setGpsStatus("error")
    }
  }, [authenticated])

  useEffect(() => {
    const checkLeaflet = () => {
      if (typeof window !== "undefined" && window.L) {
        console.log("[v0] Leaflet loaded successfully")
        setLeafletLoaded(true)
        setMapLoaded(true)
        return true
      }
      return false
    }

    if (checkLeaflet()) return

    const interval = setInterval(() => {
      if (checkLeaflet()) {
        clearInterval(interval)
      }
    }, 100)

    return () => clearInterval(interval)
  }, [])

  useEffect(() => {
    if (!leafletLoaded || !mapRef.current || mapInstanceRef.current || !authenticated) {
      console.log("[v0] Map init skipped:", {
        leafletLoaded,
        hasMapRef: !!mapRef.current,
        hasInstance: !!mapInstanceRef.current,
        authenticated,
      })
      return
    }

    console.log("[v0] Initializing map...")
    const L = window.L

    try {
      const map = L.map(mapRef.current, {
        center: [currentLocation.lat, currentLocation.lng],
        zoom: 15,
        zoomControl: true,
        attributionControl: true,
      })

      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        maxZoom: 19,
        attribution: "© OpenStreetMap contributors",
      }).addTo(map)

      const currentLocationIcon = L.divIcon({
        className: "custom-location-marker",
        html: `
          <div style="
            width: 24px;
            height: 24px;
            background: hsl(24 95% 53%);
            border: 4px solid white;
            border-radius: 50%;
            box-shadow: 0 2px 8px rgba(0,0,0,0.3);
          "></div>
        `,
        iconSize: [24, 24],
        iconAnchor: [12, 12],
      })

      const marker = L.marker([currentLocation.lat, currentLocation.lng], {
        icon: currentLocationIcon,
      }).addTo(map)

      const accuracyCircle = L.circle([currentLocation.lat, currentLocation.lng], {
        color: "hsl(24 95% 53%)",
        fillColor: "hsl(24 95% 53%)",
        fillOpacity: 0.15,
        radius: gpsAccuracy || 50,
        weight: 2,
      }).addTo(map)

      markerRef.current = marker
      accuracyCircleRef.current = accuracyCircle
      mapInstanceRef.current = map

      console.log("[v0] Map initialized successfully")
    } catch (error) {
      console.error("[v0] Map initialization error:", error)
    }

    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove()
        mapInstanceRef.current = null
      }
    }
  }, [leafletLoaded, authenticated, currentLocation.lat, currentLocation.lng])

  useEffect(() => {
    if (mapInstanceRef.current && markerRef.current && accuracyCircleRef.current) {
      markerRef.current.setLatLng([currentLocation.lat, currentLocation.lng])
      accuracyCircleRef.current.setLatLng([currentLocation.lat, currentLocation.lng])
      accuracyCircleRef.current.setRadius(gpsAccuracy || 50)
      mapInstanceRef.current.panTo([currentLocation.lat, currentLocation.lng], { animate: true, duration: 1 })
    }
  }, [currentLocation, gpsAccuracy])

  const centerOnLocation = () => {
    if (mapInstanceRef.current) {
      mapInstanceRef.current.setView([currentLocation.lat, currentLocation.lng], 15, {
        animate: true,
        duration: 0.5,
      })
    }
  }

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const files = Array.from(e.target.files)
      setUploadedFiles((prev) => [...prev, ...files])
    }
  }

  const handleSubmitReport = () => {
    if (!problemDescription || !problemLocation) {
      alert("Please fill in all required fields")
      return
    }

    const reports = JSON.parse(localStorage.getItem("problemReports") || "[]")
    const newReport = {
      id: `PR${Date.now()}`,
      description: problemDescription,
      location: problemLocation,
      timestamp: new Date().toISOString(),
      files: uploadedFiles.map((f) => ({ name: f.name, type: f.type, size: f.size })),
      status: "pending",
    }
    reports.push(newReport)
    localStorage.setItem("problemReports", JSON.stringify(reports))

    setProblemDescription("")
    setProblemLocation("")
    setUploadedFiles([])
    setReportDialogOpen(false)
    alert("Problem reported successfully! Admin will review it shortly.")
  }

  useEffect(() => {
    if (mapInstanceRef.current && clickToSetDestination) {
      const map = mapInstanceRef.current

      const onMapClick = (e: any) => {
        const { lat, lng } = e.latlng
        setDestinationCoords({ lat, lng })
        setDestination(`${lat.toFixed(6)}, ${lng.toFixed(6)}`)
        setClickToSetDestination(false)

        // Add temporary marker
        if (destinationMarker) {
          destinationMarker.remove()
        }

        const L = window.L
        const marker = L.marker([lat, lng], {
          icon: L.divIcon({
            className: "destination-marker",
            html: `
              <div style="
                width: 32px;
                height: 32px;
                background: hsl(142 76% 36%);
                border: 4px solid white;
                border-radius: 50%;
                box-shadow: 0 2px 8px rgba(0,0,0,0.3);
                display: flex;
                align-items: center;
                justify-content: center;
                color: white;
                font-size: 18px;
              ">📍</div>
            `,
            iconSize: [32, 32],
            iconAnchor: [16, 16],
          }),
        }).addTo(map)

        setDestinationMarker(marker)
      }

      map.on("click", onMapClick)

      return () => {
        map.off("click", onMapClick)
      }
    }
  }, [clickToSetDestination, mapInstanceRef.current, destinationMarker])

  const calculateRouteWithORS = async (start: { lat: number; lng: number }, end: { lat: number; lng: number }) => {
    setIsCalculatingRoute(true)

    try {
      // Call our API route instead of ORS directly to avoid CORS issues
      const response = await fetch("/api/route", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ start, end }),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || "Failed to calculate route")
      }

      const data = await response.json()
      const route = data.features[0]
      const geometry = route.geometry.coordinates
      const properties = route.properties
      const segments = properties.segments[0]

      // Convert coordinates to Leaflet format [lat, lng]
      const routeCoords = geometry.map((coord: number[]) => [coord[1], coord[0]])

      // Extract turn-by-turn steps
      const steps: RouteStep[] = segments.steps.map((step: any) => ({
        instruction: step.instruction,
        distance: step.distance,
        duration: step.duration,
        type: step.type,
        name: step.name || "Unnamed road",
      }))

      setRouteSteps(steps)
      setTotalDistance(properties.summary.distance / 1000) // Convert to km
      setTotalDuration(Math.round(properties.summary.duration / 60)) // Convert to minutes
      setCurrentStepIndex(0)
      lastAnnouncedStepRef.current = -1

      // Draw route on map
      if (mapInstanceRef.current && window.L) {
        const L = window.L

        // Remove existing route
        if (routePolyline) {
          routePolyline.remove()
        }

        // Create route polyline
        const polyline = L.polyline(routeCoords, {
          color: darkMode ? "hsl(24 95% 63%)" : "hsl(24 95% 53%)",
          weight: 5,
          opacity: 0.8,
        }).addTo(mapInstanceRef.current)

        setRoutePolyline(polyline)

        // Add destination marker
        if (destinationMarker) {
          destinationMarker.remove()
        }

        const marker = L.marker([end.lat, end.lng], {
          icon: L.divIcon({
            className: "destination-marker",
            html: `
              <div style="
                width: 32px;
                height: 32px;
                background: hsl(142 76% 36%);
                border: 4px solid white;
                border-radius: 50%;
                box-shadow: 0 2px 8px rgba(0,0,0,0.3);
                display: flex;
                align-items: center;
                justify-content: center;
                color: white;
                font-size: 18px;
              ">📍</div>
            `,
            iconSize: [32, 32],
            iconAnchor: [16, 16],
          }),
        }).addTo(mapInstanceRef.current)

        setDestinationMarker(marker)

        // Fit map to show route
        mapInstanceRef.current.fitBounds(polyline.getBounds(), { padding: [50, 50] })
      }

      console.log("[v0] Route calculated successfully:", steps.length, "steps")

      // Announce first instruction
      if (navigationVoiceEnabled && steps.length > 0) {
        announceNavigation(`Navigation started. ${steps[0].instruction}`)
        lastAnnouncedStepRef.current = 0
      }
    } catch (error) {
      console.error("[v0] Route calculation error:", error)
      alert(`Failed to calculate route: ${error instanceof Error ? error.message : "Unknown error"}. Please try again.`)
    } finally {
      setIsCalculatingRoute(false)
    }
  }

  const startNavigation = async () => {
    if (!destinationCoords && !destination) {
      alert("Please enter a destination or click on the map")
      return
    }

    let destCoords = destinationCoords

    // If destination is text, try to parse as coordinates
    if (!destCoords && destination) {
      const coords = destination.split(",").map((s) => Number.parseFloat(s.trim()))
      if (coords.length === 2 && !isNaN(coords[0]) && !isNaN(coords[1])) {
        destCoords = { lat: coords[0], lng: coords[1] }
        setDestinationCoords(destCoords)
      } else {
        alert("Please enter coordinates in format: latitude, longitude (e.g., -29.8587, 31.0218)")
        return
      }
    }

    if (!destCoords) {
      alert("Invalid destination")
      return
    }

    setNavigationActive(true)
    await calculateRouteWithORS(currentLocation, destCoords)
  }

  const stopNavigation = () => {
    setNavigationActive(false)
    setDestinationCoords(null)
    setCurrentInstruction("")
    setDistanceToDestination(0)
    setEstimatedTime(0)
    setRouteSteps([])
    setCurrentStepIndex(0)
    setTotalDistance(0)
    setTotalDuration(0)
    lastAnnouncedStepRef.current = -1

    if (routePolyline) {
      routePolyline.remove()
      setRoutePolyline(null)
    }

    if (destinationMarker) {
      destinationMarker.remove()
      setDestinationMarker(null)
    }

    if (navigationVoiceEnabled) {
      announceNavigation("Navigation stopped.")
    }
  }

  const recalculateRoute = async () => {
    if (destinationCoords) {
      console.log("[v0] Recalculating route...")
      await calculateRouteWithORS(currentLocation, destinationCoords)
    }
  }

  useEffect(() => {
    if (navigationActive && destinationCoords && routeSteps.length > 0) {
      const distance = calculateDistance(
        currentLocation.lat,
        currentLocation.lng,
        destinationCoords.lat,
        destinationCoords.lng,
      )
      setDistanceToDestination(distance)

      // Check if we've arrived
      if (distance < 0.05) {
        // Within 50 meters
        setCurrentInstruction("You have arrived at your destination")
        if (navigationVoiceEnabled && lastAnnouncedStepRef.current !== -999) {
          announceNavigation("You have arrived at your destination")
          lastAnnouncedStepRef.current = -999
        }
        setTimeout(() => stopNavigation(), 3000)
        return
      }

      // Update current step based on distance
      let cumulativeDistance = 0
      let newStepIndex = currentStepIndex

      for (let i = 0; i < routeSteps.length; i++) {
        cumulativeDistance += routeSteps[i].distance / 1000 // Convert to km
        if (cumulativeDistance > distance) {
          newStepIndex = i
          break
        }
      }

      if (newStepIndex !== currentStepIndex) {
        setCurrentStepIndex(newStepIndex)
      }

      // Get current instruction
      const currentStep = routeSteps[newStepIndex]
      if (currentStep) {
        const distanceToStep = (cumulativeDistance - distance) * 1000 // Convert to meters
        const instruction =
          distanceToStep > 100
            ? `In ${Math.round(distanceToStep)} meters: ${currentStep.instruction}`
            : currentStep.instruction

        setCurrentInstruction(instruction)

        // Announce instruction if it's a new step
        if (navigationVoiceEnabled && newStepIndex !== lastAnnouncedStepRef.current && distanceToStep < 200) {
          announceNavigation(instruction)
          lastAnnouncedStepRef.current = newStepIndex
        }
      }
    }
  }, [
    currentLocation,
    navigationActive,
    destinationCoords,
    routeSteps,
    currentStepIndex,
    navigationVoiceEnabled,
    lastAnnouncedStepRef,
  ])

  const toggleDarkMode = () => {
    setDarkMode(!darkMode)
    if (mapInstanceRef.current && window.L) {
      const L = window.L
      // Remove existing tile layer
      mapInstanceRef.current.eachLayer((layer: any) => {
        if (layer instanceof L.TileLayer) {
          mapInstanceRef.current.removeLayer(layer)
        }
      })

      // Add new tile layer based on mode
      const tileUrl = !darkMode
        ? "https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
        : "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"

      L.tileLayer(tileUrl, {
        maxZoom: 19,
        attribution: !darkMode ? "© CARTO © OpenStreetMap contributors" : "© OpenStreetMap contributors",
      }).addTo(mapInstanceRef.current)
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <Script
        src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"
        strategy="afterInteractive"
        onLoad={() => {
          console.log("[v0] Leaflet script loaded")
          setLeafletLoaded(true)
        }}
        onError={(e) => {
          console.error("[v0] Leaflet script failed to load:", e)
        }}
      />
      <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
      <style jsx global>{`
        .leaflet-container {
          background: ${darkMode ? "hsl(222 47% 11%)" : "hsl(0 0% 100%)"};
          border-radius: 0.5rem;
          z-index: 0;
        }
        .custom-location-marker {
          background: transparent !important;
          border: none !important;
        }
        .destination-marker {
          background: transparent !important;
          border: none !important;
        }
      `}</style>

      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">My Location</h1>
            <p className="text-sm text-muted-foreground">Real-time GPS tracking</p>
          </div>
          <Button variant="outline" onClick={handleLogout}>
            <LogOut className="mr-2 h-4 w-4" />
            Logout
          </Button>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6">
        <div className="grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-4">
            {navigationActive && (
              <Card className="border-primary">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center gap-2">
                      <Navigation className="h-5 w-5 text-primary animate-pulse" />
                      Navigation Active
                    </CardTitle>
                    <div className="flex items-center gap-2">
                      <Button
                        size="icon"
                        variant="ghost"
                        onClick={recalculateRoute}
                        title="Recalculate route"
                        disabled={isCalculatingRoute}
                      >
                        <RefreshCw className={`h-4 w-4 ${isCalculatingRoute ? "animate-spin" : ""}`} />
                      </Button>
                      <Button
                        size="icon"
                        variant="ghost"
                        onClick={() => setNavigationVoiceEnabled(!navigationVoiceEnabled)}
                        title={navigationVoiceEnabled ? "Disable voice" : "Enable voice"}
                      >
                        {navigationVoiceEnabled ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
                      </Button>
                      <Button size="icon" variant="destructive" onClick={stopNavigation}>
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 bg-primary/10 rounded-lg">
                      <p className="text-sm font-medium mb-1">Current Instruction:</p>
                      <p className="text-lg">{currentInstruction}</p>
                      {routeSteps.length > 0 && (
                        <p className="text-xs text-muted-foreground mt-2">
                          Step {currentStepIndex + 1} of {routeSteps.length}
                        </p>
                      )}
                    </div>
                    <div className="grid grid-cols-3 gap-4">
                      <div>
                        <p className="text-xs text-muted-foreground">Distance</p>
                        <p className="text-xl font-bold">{distanceToDestination.toFixed(1)} km</p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Est. Time</p>
                        <p className="text-xl font-bold">{totalDuration} min</p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Speed</p>
                        <p className="text-xl font-bold">{currentSpeed} km/h</p>
                      </div>
                    </div>
                    {routeSteps.length > 0 && (
                      <div className="max-h-[200px] overflow-y-auto space-y-2 border rounded-lg p-3">
                        <p className="text-xs font-medium text-muted-foreground mb-2">Turn-by-Turn Directions:</p>
                        {routeSteps.map((step, index) => (
                          <div
                            key={index}
                            className={`text-sm p-2 rounded ${
                              index === currentStepIndex ? "bg-primary/20 border border-primary" : "bg-muted/50"
                            }`}
                          >
                            <p className="font-medium">
                              {index + 1}. {step.instruction}
                            </p>
                            <p className="text-xs text-muted-foreground">
                              {(step.distance / 1000).toFixed(2)} km • {Math.round(step.duration / 60)} min
                            </p>
                          </div>
                        ))}
                      </div>
                    )}
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <div className="w-3 h-3 rounded-full bg-primary animate-pulse" />
                      Voice directions {navigationVoiceEnabled ? "enabled" : "disabled"}
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      <MapPin className="h-5 w-5 text-primary" />
                      Live Location Map
                    </CardTitle>
                    <CardDescription>{leafletLoaded ? "Your current GPS position" : "Loading map..."}</CardDescription>
                  </div>
                  <Button
                    size="icon"
                    variant="outline"
                    onClick={toggleDarkMode}
                    title={darkMode ? "Light mode" : "Dark mode"}
                  >
                    {darkMode ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="p-4 relative">
                {!leafletLoaded && (
                  <div className="absolute inset-0 flex items-center justify-center bg-muted/50 rounded-lg z-10">
                    <div className="text-center">
                      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
                      <p className="text-sm text-muted-foreground">Loading map...</p>
                    </div>
                  </div>
                )}
                <div
                  ref={mapRef}
                  className="w-full h-[600px] rounded-lg border border-border"
                  style={{ minHeight: "600px" }}
                />
                <Button
                  size="icon"
                  className="absolute bottom-6 right-6 rounded-full shadow-lg"
                  onClick={centerOnLocation}
                  title="Center on my location"
                  disabled={!leafletLoaded}
                >
                  <Crosshair className="h-5 w-5" />
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MapPin className="h-5 w-5 text-primary" />
                  GPS Status
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div>
                    <p className="text-xs text-muted-foreground">Speed</p>
                    <p className="text-2xl font-bold">
                      {currentSpeed} <span className="text-sm">km/h</span>
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Heading</p>
                    <p className="text-2xl font-bold">{heading}°</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Latitude</p>
                    <p className="text-sm font-mono">{currentLocation.lat.toFixed(6)}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Longitude</p>
                    <p className="text-sm font-mono">{currentLocation.lng.toFixed(6)}</p>
                  </div>
                </div>
                <Badge variant="outline" className="mt-4">
                  <div
                    className={`w-2 h-2 rounded-full mr-2 ${gpsStatus === "active" ? "bg-green-500" : gpsStatus === "searching" ? "bg-yellow-500" : "bg-red-500"}`}
                  />
                  {gpsStatus === "active"
                    ? `GPS Active - Accuracy: ${Math.round(gpsAccuracy)}m`
                    : gpsStatus === "searching"
                      ? "Searching for GPS..."
                      : "GPS Error - Using Default Location"}
                </Badge>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-4">
            <Card className="border-primary/20">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Navigation className="h-5 w-5 text-primary" />
                  Live Navigator
                </CardTitle>
                <CardDescription>GPS navigation with voice directions</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="space-y-2">
                    <Label htmlFor="destination">Destination</Label>
                    <Input
                      id="destination"
                      placeholder="Enter coordinates: lat, lng"
                      value={destination}
                      onChange={(e) => setDestination(e.target.value)}
                      disabled={navigationActive}
                    />
                    <p className="text-xs text-muted-foreground">Example: -29.8587, 31.0218</p>
                  </div>
                  <Button
                    variant="outline"
                    className="w-full bg-transparent"
                    onClick={() => setClickToSetDestination(!clickToSetDestination)}
                    disabled={navigationActive}
                  >
                    <MapPinned className="mr-2 h-4 w-4" />
                    {clickToSetDestination ? "Cancel Map Selection" : "Click Map to Set Destination"}
                  </Button>
                  {clickToSetDestination && (
                    <p className="text-xs text-primary animate-pulse">
                      Click anywhere on the map to set your destination
                    </p>
                  )}
                  {!navigationActive ? (
                    <Button onClick={startNavigation} className="w-full" disabled={isCalculatingRoute}>
                      {isCalculatingRoute ? (
                        <>
                          <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                          Calculating Route...
                        </>
                      ) : (
                        <>
                          <Navigation className="mr-2 h-4 w-4" />
                          Start Navigation
                        </>
                      )}
                    </Button>
                  ) : (
                    <Button onClick={stopNavigation} variant="destructive" className="w-full">
                      <X className="mr-2 h-4 w-4" />
                      Stop Navigation
                    </Button>
                  )}
                  <div className="p-3 bg-muted rounded-lg text-xs space-y-1">
                    <p className="font-medium">Features:</p>
                    <ul className="list-disc list-inside text-muted-foreground space-y-1">
                      <li>Real-time GPS tracking</li>
                      <li>OpenRouteService routing</li>
                      <li>Turn-by-turn voice directions</li>
                      <li>Flexible route visualization</li>
                      <li>Distance & time estimates</li>
                      <li>Click map to set destination</li>
                      <li>Recalculate route option</li>
                      <li>Dark/Light mode toggle</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <Bell className="h-5 w-5 text-primary" />
                    Traffic Alerts
                    {unreadCount > 0 && (
                      <Badge variant="destructive" className="ml-2">
                        {unreadCount}
                      </Badge>
                    )}
                  </CardTitle>
                  <Button
                    size="icon"
                    variant="ghost"
                    onClick={() => {
                      const newState = !voiceEnabled
                      setVoiceEnabled(newState)
                      console.log("[v0] Voice toggle clicked, new state:", newState)
                    }}
                    title={voiceEnabled ? "Disable voice alerts" : "Enable voice alerts"}
                  >
                    {voiceEnabled ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
                  </Button>
                </div>
                <CardDescription>
                  AI & Admin notifications
                  {voiceEnabled && <span className="text-primary"> • Voice enabled</span>}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 max-h-[400px] overflow-y-auto">
                  {alerts.length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">
                      <Bell className="h-12 w-12 mx-auto mb-2 opacity-50" />
                      <p className="text-sm">No alerts at this time</p>
                    </div>
                  ) : (
                    <>
                      {alerts.map((alert) => (
                        <div
                          key={alert.id}
                          className={`p-3 border rounded-lg ${
                            alert.read ? "border-border bg-muted/50" : "border-primary/50 bg-primary/5"
                          }`}
                          onClick={() => markAlertAsRead(alert.id)}
                        >
                          <div className="flex items-start justify-between mb-1">
                            <Badge
                              variant={
                                alert.priority === "high"
                                  ? "destructive"
                                  : alert.priority === "medium"
                                    ? "default"
                                    : "secondary"
                              }
                            >
                              {alert.type === "ai" ? "AI" : "ADMIN"}
                            </Badge>
                            <span className="text-xs text-muted-foreground">
                              {new Date(alert.timestamp).toLocaleTimeString()}
                            </span>
                          </div>
                          <p className="font-semibold text-sm mb-1">{alert.title}</p>
                          <p className="text-xs text-muted-foreground">{alert.message}</p>
                        </div>
                      ))}
                      <Button variant="outline" size="sm" className="w-full bg-transparent" onClick={clearAllAlerts}>
                        Clear All Alerts
                      </Button>
                    </>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card className="border-destructive/20">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-destructive" />
                  Report Road Problem
                </CardTitle>
                <CardDescription>Help improve traffic management</CardDescription>
              </CardHeader>
              <CardContent>
                <Dialog open={reportDialogOpen} onOpenChange={setReportDialogOpen}>
                  <DialogTrigger asChild>
                    <Button variant="outline" className="w-full bg-transparent">
                      <Camera className="mr-2 h-4 w-4" />
                      Report Issue
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-md">
                    <DialogHeader>
                      <DialogTitle>Report Road Problem</DialogTitle>
                      <DialogDescription>Describe the issue and upload photo/video evidence</DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="problem-location">Location *</Label>
                        <Input
                          id="problem-location"
                          placeholder="e.g., M4 Highway near Brickfield Rd"
                          value={problemLocation}
                          onChange={(e) => setProblemLocation(e.target.value)}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="problem-description">Description *</Label>
                        <Textarea
                          id="problem-description"
                          placeholder="Describe the problem (pothole, broken light, accident, etc.)"
                          value={problemDescription}
                          onChange={(e) => setProblemDescription(e.target.value)}
                          rows={4}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="problem-files">Upload Evidence (Photo/Video)</Label>
                        <div className="border-2 border-dashed border-border rounded-lg p-4 text-center">
                          <input
                            id="problem-files"
                            type="file"
                            accept="image/*,video/*"
                            multiple
                            onChange={handleFileUpload}
                            className="hidden"
                          />
                          <label htmlFor="problem-files" className="cursor-pointer">
                            <Upload className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
                            <p className="text-sm text-muted-foreground">Click to upload images or videos</p>
                          </label>
                        </div>
                        {uploadedFiles.length > 0 && (
                          <div className="space-y-2 mt-2">
                            {uploadedFiles.map((file, index) => (
                              <div key={index} className="flex items-center gap-2 text-sm p-2 bg-muted rounded">
                                {file.type.startsWith("video") ? (
                                  <FileVideo className="h-4 w-4" />
                                ) : (
                                  <Camera className="h-4 w-4" />
                                )}
                                <span className="flex-1 truncate">{file.name}</span>
                                <span className="text-xs text-muted-foreground">
                                  {(file.size / 1024 / 1024).toFixed(2)} MB
                                </span>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                      <Button onClick={handleSubmitReport} className="w-full">
                        Submit Report
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Current Address</CardTitle>
                <CardDescription>Based on GPS coordinates</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  {currentLocation.lat.toFixed(6)}, {currentLocation.lng.toFixed(6)}
                </p>
                <p className="text-sm mt-2">Durban, KwaZulu-Natal, South Africa</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}
