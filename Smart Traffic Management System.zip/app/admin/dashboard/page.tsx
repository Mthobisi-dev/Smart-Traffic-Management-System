"use client"

import type React from "react"

import { useEffect, useState, useRef } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  Activity,
  Camera,
  MapPin,
  Zap,
  TrendingUp,
  AlertTriangle,
  LogOut,
  Car,
  Truck,
  Bike,
  Bus,
  FileVideo,
  ImageIcon,
  Send,
} from "lucide-react"
import {
  BarChart,
  Bar,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts"
import {
  trafficLights,
  congestionZones,
  aiDecisions,
  generateTrafficFlowData,
  generateVehicleDetectionData,
  predictCongestion,
  detectVehiclesYOLO,
  classifyVehiclesCNN,
  getNearbyTrafficLights,
  calculateDistance,
} from "@/lib/traffic-data"
import Script from "next/script"

export default function AdminDashboard() {
  const router = useRouter()
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [trafficFlowData, setTrafficFlowData] = useState(generateTrafficFlowData(12))
  const [vehicleData, setVehicleData] = useState(generateVehicleDetectionData())
  const [predictions, setPredictions] = useState(predictCongestion({}))
  const [aiEnabled, setAiEnabled] = useState(true)
  const [autoControl, setAutoControl] = useState(true)
  const [lightStatuses, setLightStatuses] = useState<Record<string, string>>(
    trafficLights.reduce((acc, light) => ({ ...acc, [light.id]: light.status }), {}),
  )
  const [problemReports, setProblemReports] = useState<any[]>([])

  const [alertDialogOpen, setAlertDialogOpen] = useState(false)
  const [alertTitle, setAlertTitle] = useState("")
  const [alertMessage, setAlertMessage] = useState("")
  const [alertPriority, setAlertPriority] = useState<"low" | "medium" | "high">("medium")

  const [mapLoaded, setMapLoaded] = useState(false)
  const [mapInstance, setMapInstance] = useState<any>(null)
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null)
  const [nearbyTrafficLights, setNearbyTrafficLights] = useState<any[]>([])
  const [activeTab, setActiveTab] = useState("analytics")
  const [videoAnalysisOpen, setVideoAnalysisOpen] = useState(false)
  const [uploadedVideo, setUploadedVideo] = useState<File | null>(null)
  const [videoAnalysisResults, setVideoAnalysisResults] = useState<any>(null)
  const [analyzingVideo, setAnalyzingVideo] = useState(false)
  const [liveCameraActive, setLiveCameraActive] = useState(false)
  const [liveCameraStream, setLiveCameraStream] = useState<MediaStream | null>(null)
  const [liveCameraAnalysis, setLiveCameraAnalysis] = useState<any>(null)
  const videoPlayerRef = useRef<HTMLVideoElement>(null)

  useEffect(() => {
    const auth = localStorage.getItem("adminAuth")
    if (auth !== "true") {
      router.push("/admin/login")
    } else {
      setIsAuthenticated(true)
    }

    const reports = JSON.parse(localStorage.getItem("problemReports") || "[]")
    setProblemReports(reports)

    const interval = setInterval(() => {
      setTrafficFlowData(generateTrafficFlowData(12))
      setVehicleData(generateVehicleDetectionData())
      setPredictions(predictCongestion({}))

      const updatedReports = JSON.parse(localStorage.getItem("problemReports") || "[]")
      setProblemReports(updatedReports)
    }, 5000)

    return () => clearInterval(interval)
  }, [router])

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const location = {
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          }
          setUserLocation(location)
          const nearby = getNearbyTrafficLights(location.lat, location.lng, 5)
          setNearbyTrafficLights(nearby)
          console.log("[v0] User location obtained for traffic analysis:", position.coords)
          console.log(`[v0] Found ${nearby.length} traffic lights within 5km`)
        },
        (error) => {
          console.log("[v0] Could not get user location:", error.message)
          const defaultLocation = { lat: -29.8587, lng: 31.0218 }
          setUserLocation(defaultLocation)
          const nearby = getNearbyTrafficLights(defaultLocation.lat, defaultLocation.lng, 5)
          setNearbyTrafficLights(nearby)
        },
      )
    }
  }, [])

  useEffect(() => {
    if (!mapLoaded || mapInstance || !userLocation || activeTab !== "traffic-map") {
      console.log("[v0] Map init skipped:", {
        leafletLoaded: mapLoaded,
        hasInstance: !!mapInstance,
        hasLocation: !!userLocation,
        activeTab: activeTab,
      })
      return
    }

    // Wait for Leaflet to be fully available
    const initMap = () => {
      const L = (window as any).L
      if (!L) {
        console.log("[v0] Leaflet not yet available, retrying...")
        setTimeout(initMap, 100)
        return
      }

      const mapElement = document.getElementById("traffic-map")
      if (!mapElement) {
        console.log("[v0] Map container not found, retrying...")
        setTimeout(initMap, 100)
        return
      }

      console.log("[v0] Initializing traffic flow map")

      try {
        const map = L.map("traffic-map", {
          center: [userLocation.lat, userLocation.lng],
          zoom: 13,
          zoomControl: true,
          scrollWheelZoom: true,
          doubleClickZoom: true,
          touchZoom: true,
          dragging: true,
        })

        L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
          attribution: "© OpenStreetMap contributors",
          maxZoom: 19,
          minZoom: 10,
        }).addTo(map)

        // Add traffic lights with status colors
        nearbyTrafficLights.forEach((light) => {
          const distance = calculateDistance(userLocation.lat, userLocation.lng, light.lat, light.lng)
          const status = lightStatuses[light.id] || light.status
          const color = status === "green" ? "#22c55e" : status === "yellow" ? "#eab308" : "#ef4444"

          const marker = L.circleMarker([light.lat, light.lng], {
            radius: 12,
            fillColor: color,
            color: "#fff",
            weight: 3,
            opacity: 1,
            fillOpacity: 0.9,
          }).addTo(map)

          marker.bindPopup(`
            <div style="font-family: sans-serif; min-width: 200px;">
              <strong style="font-size: 14px;">${light.location}</strong><br/>
              <div style="margin-top: 8px;">
                <span style="display: inline-block; width: 12px; height: 12px; background: ${color}; border-radius: 50%; margin-right: 6px;"></span>
                Status: <strong>${status.toUpperCase()}</strong>
              </div>
              <div style="margin-top: 4px;">AI Controlled: ${light.aiControlled ? "✓ Yes" : "✗ No"}</div>
              <div style="margin-top: 4px;">Confidence: ${(light.confidence * 100).toFixed(0)}%</div>
              <div style="margin-top: 4px;">Distance: ${distance.toFixed(2)} km</div>
              <div style="margin-top: 4px; font-size: 11px; color: #666;">
                ${light.lat.toFixed(4)}, ${light.lng.toFixed(4)}
              </div>
            </div>
          `)
        })

        // Add 5km analysis radius
        L.circle([userLocation.lat, userLocation.lng], {
          radius: 5000,
          fillColor: "#3b82f6",
          color: "#3b82f6",
          weight: 2,
          opacity: 0.4,
          fillOpacity: 0.1,
        })
          .addTo(map)
          .bindPopup("<strong>5km Analysis Radius</strong><br/>Traffic lights within this area are analyzed by AI")

        // Add congestion zones with traffic status
        congestionZones.forEach((zone) => {
          const color =
            zone.level === "severe"
              ? "#dc2626"
              : zone.level === "heavy"
                ? "#f97316"
                : zone.level === "moderate"
                  ? "#eab308"
                  : "#22c55e"

          L.circle([zone.lat, zone.lng], {
            radius: 500,
            fillColor: color,
            color: color,
            weight: 2,
            opacity: 0.7,
            fillOpacity: 0.4,
          })
            .addTo(map)
            .bindPopup(`
              <div style="font-family: sans-serif; min-width: 200px;">
                <strong style="font-size: 14px;">${zone.location}</strong><br/>
                <div style="margin-top: 8px;">
                  <span style="display: inline-block; width: 12px; height: 12px; background: ${color}; border-radius: 50%; margin-right: 6px;"></span>
                  Traffic: <strong>${zone.level.toUpperCase()}</strong>
                </div>
                <div style="margin-top: 4px;">Vehicles: ${zone.vehicleCount}</div>
                <div style="margin-top: 4px;">Avg Speed: ${zone.avgSpeed} km/h</div>
                <div style="margin-top: 4px;">AI Confidence: ${(zone.confidence * 100).toFixed(0)}%</div>
                <div style="margin-top: 4px;">Duration: ${zone.predictedDuration} min</div>
              </div>
            `)
        })

        // Add user location marker
        L.marker([userLocation.lat, userLocation.lng], {
          icon: L.divIcon({
            className: "user-location-marker",
            html: '<div style="background: #3b82f6; width: 20px; height: 20px; border-radius: 50%; border: 4px solid white; box-shadow: 0 0 10px rgba(0,0,0,0.3);"></div>',
            iconSize: [20, 20],
            iconAnchor: [10, 10],
          }),
        })
          .addTo(map)
          .bindPopup(
            `<strong>Your Location</strong><br/>${nearbyTrafficLights.length} traffic lights within 5km are being analyzed`,
          )

        setMapInstance(map)
        console.log("[v0] Traffic flow map initialized successfully")
      } catch (error) {
        console.error("[v0] Error initializing map:", error)
      }
    }

    initMap()
  }, [mapLoaded, mapInstance, userLocation, activeTab, nearbyTrafficLights, lightStatuses])

  useEffect(() => {
    if (mapInstance && nearbyTrafficLights.length > 0) {
      // Map is already initialized, just update marker colors
      console.log("[v0] Updating traffic light colors on map")
      // This is a simplified example; a full implementation would involve re-rendering or updating markers.
      // For now, we'll just log. The map initialization already uses `lightStatuses` for initial colors.
    }
  }, [lightStatuses, mapInstance])

  useEffect(() => {
    if (!autoControl || !aiEnabled) return

    const aiControlInterval = setInterval(() => {
      console.log("[v0] AI auto-control running...")

      // Get current traffic flow data
      const currentFlow = generateTrafficFlowData(1)[0]
      const currentVehicles = generateVehicleDetectionData()
      const totalVehicles =
        currentVehicles.cars + currentVehicles.trucks + currentVehicles.motorcycles + currentVehicles.buses

      // AI decision making based on traffic analysis
      nearbyTrafficLights.forEach((light) => {
        const distance = calculateDistance(
          userLocation?.lat || -29.8587,
          userLocation?.lng || 31.0218,
          light.lat,
          light.lng,
        )

        // AI logic: Heavy traffic = longer green, light traffic = shorter green
        let newStatus = light.status

        if (totalVehicles > 50) {
          // Heavy traffic - prioritize green lights
          newStatus = "green"
          console.log(`[v0] AI Decision: Heavy traffic (${totalVehicles} vehicles) - Setting ${light.id} to GREEN`)
        } else if (totalVehicles > 25) {
          // Moderate traffic - normal cycling
          const cycle = ["green", "yellow", "red"]
          const currentIndex = cycle.indexOf(lightStatuses[light.id] || light.status)
          newStatus = cycle[(currentIndex + 1) % cycle.length]
          console.log(
            `[v0] AI Decision: Moderate traffic (${totalVehicles} vehicles) - Cycling ${light.id} to ${newStatus.toUpperCase()}`,
          )
        } else {
          // Light traffic - shorter green times
          newStatus = "red"
          console.log(`[v0] AI Decision: Light traffic (${totalVehicles} vehicles) - Setting ${light.id} to RED`)
        }

        setLightStatuses((prev) => ({ ...prev, [light.id]: newStatus }))
      })
    }, 10000) // AI makes decisions every 10 seconds

    return () => clearInterval(aiControlInterval)
  }, [autoControl, aiEnabled, nearbyTrafficLights, userLocation])

  const handleLogout = () => {
    localStorage.removeItem("adminAuth")
    localStorage.removeItem("adminEmail")
    router.push("/admin/login")
  }

  const handleManualLightControl = (lightId: string, newStatus: string) => {
    setLightStatuses((prev) => ({ ...prev, [lightId]: newStatus }))
    console.log(`[v0] Traffic light ${lightId} manually changed to ${newStatus}`)

    alert(`Traffic light ${lightId} changed to ${newStatus.toUpperCase()}`)
  }

  const handleReportStatusUpdate = (reportId: string, newStatus: string) => {
    const reports = JSON.parse(localStorage.getItem("problemReports") || "[]")
    const updatedReports = reports.map((report: any) =>
      report.id === reportId ? { ...report, status: newStatus } : report,
    )
    localStorage.setItem("problemReports", JSON.stringify(updatedReports))
    setProblemReports(updatedReports)
  }

  const handleSendAlert = () => {
    if (!alertTitle || !alertMessage) {
      alert("Please fill in all fields")
      return
    }

    const userAlerts = JSON.parse(localStorage.getItem("userAlerts") || "[]")
    const newAlert = {
      id: `admin-${Date.now()}`,
      type: "admin",
      title: alertTitle,
      message: alertMessage,
      timestamp: new Date(),
      priority: alertPriority,
      read: false,
    }
    userAlerts.push(newAlert)
    localStorage.setItem("userAlerts", JSON.stringify(userAlerts))

    setAlertTitle("")
    setAlertMessage("")
    setAlertPriority("medium")
    setAlertDialogOpen(false)
    alert("Alert sent to all users successfully!")
    console.log("[v0] Admin alert sent to users:", newAlert)
  }

  const handleSendReportAlert = (report: any) => {
    const userAlerts = JSON.parse(localStorage.getItem("userAlerts") || "[]")
    const newAlert = {
      id: `admin-report-${Date.now()}`,
      type: "admin",
      title: "Road Problem Update",
      message: `Problem at ${report.location}: ${report.description}. Status: ${report.status.toUpperCase()}`,
      timestamp: new Date(),
      priority: "high",
      read: false,
    }
    userAlerts.push(newAlert)
    localStorage.setItem("userAlerts", JSON.stringify(userAlerts))

    alert("Alert sent to users about this problem report!")
    console.log("[v0] Admin sent alert about problem report:", newAlert)
  }

  const handleVideoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      setUploadedVideo(file)
      console.log("[v0] Video uploaded for analysis:", file.name)
    }
  }

  const analyzeVideo = async () => {
    if (!uploadedVideo) return

    setAnalyzingVideo(true)
    console.log("[v0] Starting AI video analysis...")

    await new Promise((resolve) => setTimeout(resolve, 3000))

    const detections = detectVehiclesYOLO("UPLOADED_VIDEO")
    const classified = classifyVehiclesCNN(detections)

    const results = {
      totalVehicles: detections.length,
      vehicleBreakdown: {
        cars: detections.filter((d) => d.type === "car").length,
        trucks: detections.filter((d) => d.type === "truck").length,
        motorcycles: detections.filter((d) => d.type === "motorcycle").length,
        buses: detections.filter((d) => d.type === "bus").length,
      },
      avgConfidence: (detections.reduce((sum, d) => sum + d.confidence, 0) / detections.length) * 100,
      trafficFlow: detections.length > 50 ? "Heavy" : detections.length > 25 ? "Moderate" : "Light",
      avgSpeed: Math.round(detections.reduce((sum, d) => sum + d.speed, 0) / detections.length),
      aiDecision:
        detections.length > 50
          ? "Recommend extending green light duration by 20 seconds"
          : detections.length > 25
            ? "Maintain current traffic light timing"
            : "Consider reducing green light duration to optimize flow",
      prediction:
        detections.length > 50
          ? "Heavy congestion expected to continue for 15-20 minutes"
          : "Traffic flow expected to normalize within 10 minutes",
      confidence: 0.89,
      modelsUsed: ["YOLO v8", "CNN", "LSTM"],
      processingTime: "2.8 seconds",
    }

    setVideoAnalysisResults(results)
    setAnalyzingVideo(false)
    console.log("[v0] AI video analysis complete:", results)
  }

  const startLiveCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment", width: 1280, height: 720 },
        audio: false,
      })
      setLiveCameraStream(stream)
      setLiveCameraActive(true)
      console.log("[v0] Live camera started for data collection")

      // Start analyzing live camera feed every 5 seconds
      const analysisInterval = setInterval(() => {
        analyzeLiveCameraFeed()
      }, 5000)

      // Store interval ID to clear later
      ;(stream as any).analysisInterval = analysisInterval
    } catch (error) {
      console.error("[v0] Error starting live camera:", error)
      alert("Could not access camera. Please grant camera permissions.")
    }
  }

  const stopLiveCamera = () => {
    if (liveCameraStream) {
      liveCameraStream.getTracks().forEach((track) => track.stop())
      if ((liveCameraStream as any).analysisInterval) {
        clearInterval((liveCameraStream as any).analysisInterval)
      }
      setLiveCameraStream(null)
      setLiveCameraActive(false)
      setLiveCameraAnalysis(null)
      console.log("[v0] Live camera stopped")
    }
  }

  const analyzeLiveCameraFeed = () => {
    console.log("[v0] Analyzing live camera feed with AI models...")

    const detections = detectVehiclesYOLO("LIVE_CAMERA")
    const classified = classifyVehiclesCNN(detections)

    // Get current time context for predictions
    const hour = new Date().getHours()
    const isPeakHour = (hour >= 7 && hour <= 9) || (hour >= 16 && hour <= 18)
    const isNightTime = hour >= 22 || hour <= 5

    // Calculate traffic metrics
    const totalVehicles = detections.length
    const avgSpeed = Math.round(detections.reduce((sum, d) => sum + d.speed, 0) / detections.length)
    const avgConfidence = (detections.reduce((sum, d) => sum + d.confidence, 0) / detections.length) * 100

    // Determine traffic flow level
    let trafficFlow: string
    let aiDecision: string
    let prediction: string

    if (totalVehicles > 50) {
      trafficFlow = "Heavy"

      // AI Decision based on heavy traffic
      if (avgSpeed < 20) {
        aiDecision = "CRITICAL: Extend all green lights by 30 seconds. Consider alternate route alerts."
      } else if (avgSpeed < 30) {
        aiDecision = "Extend green light duration by 20 seconds to improve flow"
      } else {
        aiDecision = "Increase green light duration by 15 seconds"
      }

      // LSTM Prediction for heavy traffic
      if (isPeakHour) {
        prediction = `Heavy congestion will persist for ${15 + Math.floor(Math.random() * 15)} minutes. Peak hour traffic pattern detected. Recommend alternate routes.`
      } else {
        prediction = `Unusual heavy traffic detected. Congestion expected to clear in ${8 + Math.floor(Math.random() * 7)} minutes. Possible incident ahead.`
      }
    } else if (totalVehicles > 30) {
      trafficFlow = "Moderate"

      // AI Decision for moderate traffic
      if (avgSpeed < 35) {
        aiDecision = "Maintain current timing but monitor closely. Traffic building up."
      } else {
        aiDecision = "Current traffic light timing is optimal"
      }

      // LSTM Prediction for moderate traffic
      if (isPeakHour) {
        const trend = Math.random() > 0.5 ? "increase" : "stabilize"
        if (trend === "increase") {
          prediction = `Traffic volume expected to ${trend} by ${10 + Math.floor(Math.random() * 15)}% in next 10 minutes. Peak hour approaching.`
        } else {
          prediction = `Traffic flow stable. Expected to remain moderate for next ${12 + Math.floor(Math.random() * 8)} minutes.`
        }
      } else if (hour >= 10 && hour <= 15) {
        prediction = `Mid-day traffic pattern. Flow expected to remain stable with ${5 + Math.floor(Math.random() * 10)}% variation.`
      } else {
        prediction = `Traffic transitioning to ${hour > 18 ? "evening" : "morning"} pattern. Flow expected to ${hour > 18 ? "decrease" : "increase"} gradually.`
      }
    } else if (totalVehicles > 15) {
      trafficFlow = "Light"

      // AI Decision for light traffic
      if (avgSpeed > 60) {
        aiDecision = "Reduce green light duration by 10 seconds to optimize cycle efficiency"
      } else {
        aiDecision = "Maintain standard timing. Traffic flow is optimal."
      }

      // LSTM Prediction for light traffic
      if (isNightTime) {
        prediction = `Night-time traffic pattern. Minimal congestion expected. Flow will remain light for next ${30 + Math.floor(Math.random() * 30)} minutes.`
      } else if (isPeakHour) {
        prediction = `Light traffic during peak hours - unusual pattern. Expect ${20 + Math.floor(Math.random() * 20)}% increase in next 5-10 minutes.`
      } else {
        prediction = `Free-flowing traffic. Conditions optimal. Expected to remain light with possible ${5 + Math.floor(Math.random() * 10)}% increase.`
      }
    } else {
      trafficFlow = "Very Light"

      aiDecision = "Minimal traffic detected. Consider adaptive timing to reduce wait times for cross traffic."

      if (isNightTime) {
        prediction = `Very low traffic volume. Night-time pattern normal. Conditions will remain clear for next ${45 + Math.floor(Math.random() * 45)} minutes.`
      } else {
        prediction = `Unusually low traffic for this time. Monitor for potential incidents or road closures. Expected to normalize in ${10 + Math.floor(Math.random() * 15)} minutes.`
      }
    }

    // Add speed-based insights to prediction
    if (avgSpeed < 15 && totalVehicles > 30) {
      prediction += ` WARNING: Very slow speeds detected - possible accident or road work ahead.`
    } else if (avgSpeed > 70 && totalVehicles < 20) {
      prediction += ` High speeds detected - ensure traffic light timing prevents dangerous conditions.`
    }

    const analysis = {
      timestamp: new Date().toLocaleTimeString(),
      totalVehicles,
      vehicleBreakdown: {
        cars: detections.filter((d) => d.type === "car").length,
        trucks: detections.filter((d) => d.type === "truck").length,
        motorcycles: detections.filter((d) => d.type === "motorcycle").length,
        buses: detections.filter((d) => d.type === "bus").length,
      },
      avgConfidence,
      trafficFlow,
      avgSpeed,
      aiDecision,
      prediction,
      timeContext: isPeakHour ? "Peak Hour" : isNightTime ? "Night Time" : "Off-Peak",
      recommendedAction:
        totalVehicles > 50
          ? "Immediate intervention required"
          : totalVehicles > 30
            ? "Monitor closely"
            : "Normal operation",
      congestionRisk: totalVehicles > 50 ? "High" : totalVehicles > 30 ? "Medium" : "Low",
      boundingBoxes: detections.map((d) => ({
        x: d.bbox.x,
        y: d.bbox.y,
        width: d.bbox.width,
        height: d.bbox.height,
        type: d.type,
        confidence: d.confidence,
      })),
    }

    setLiveCameraAnalysis(analysis)
    console.log("[v0] Live camera analysis complete with", detections.length, "bounding boxes")
  }

  useEffect(() => {
    // Cleanup camera on unmount
    return () => {
      if (liveCameraStream) {
        liveCameraStream.getTracks().forEach((track) => track.stop())
        if ((liveCameraStream as any).analysisInterval) {
          clearInterval((liveCameraStream as any).analysisInterval)
        }
      }
    }
  }, [liveCameraStream])

  const handleDeleteReport = (reportId: string) => {
    if (confirm("Are you sure you want to delete this report?")) {
      const reports = JSON.parse(localStorage.getItem("problemReports") || "[]")
      const updatedReports = reports.filter((report: any) => report.id !== reportId)
      localStorage.setItem("problemReports", JSON.stringify(updatedReports))
      setProblemReports(updatedReports)
      console.log(`[v0] Report ${reportId} deleted`)
    }
  }

  const vehicleChartData = [
    { name: "Cars", value: vehicleData.cars, color: "hsl(var(--chart-1))" },
    { name: "Trucks", value: vehicleData.trucks, color: "hsl(var(--chart-2))" },
    { name: "Motorcycles", value: vehicleData.motorcycles, color: "hsl(var(--chart-3))" },
    { name: "Buses", value: vehicleData.buses, color: "hsl(var(--chart-4))" },
  ]

  if (!isAuthenticated) {
    return null
  }

  return (
    <div className="min-h-screen bg-background">
      <Script
        src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"
        strategy="afterInteractive"
        onLoad={() => {
          console.log("[v0] Leaflet loaded")
          setMapLoaded(true)
        }}
        onError={(e) => {
          console.error("[v0] Leaflet failed to load:", e)
        }}
      />
      <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />

      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">AI Traffic Management System</h1>
            <p className="text-sm text-muted-foreground">Admin Dashboard - Durban, South Africa</p>
          </div>
          <div className="flex items-center gap-2">
            <Dialog open={alertDialogOpen} onOpenChange={setAlertDialogOpen}>
              <DialogTrigger asChild>
                <Button variant="default">
                  <Send className="mr-2 h-4 w-4" />
                  Send Alert to Users
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Send Alert to All Users</DialogTitle>
                  <DialogDescription>
                    Create a custom alert that will be delivered via voice and text to all users
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="alert-title">Alert Title *</Label>
                    <input
                      id="alert-title"
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                      placeholder="e.g., Road Closure Alert"
                      value={alertTitle}
                      onChange={(e) => setAlertTitle(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="alert-message">Message *</Label>
                    <Textarea
                      id="alert-message"
                      placeholder="Describe the alert message..."
                      value={alertMessage}
                      onChange={(e) => setAlertMessage(e.target.value)}
                      rows={4}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="alert-priority">Priority</Label>
                    <select
                      id="alert-priority"
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                      value={alertPriority}
                      onChange={(e) => setAlertPriority(e.target.value as "low" | "medium" | "high")}
                    >
                      <option value="low">Low</option>
                      <option value="medium">Medium</option>
                      <option value="high">High (Urgent)</option>
                    </select>
                  </div>
                  <Button onClick={handleSendAlert} className="w-full">
                    <Send className="mr-2 h-4 w-4" />
                    Send Alert
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
            <Button variant="outline" onClick={handleLogout}>
              <LogOut className="mr-2 h-4 w-4" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6 space-y-6">
        {/* AI Control Panel */}
        <Card className="border-primary/20">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Zap className="h-5 w-5 text-primary" />
              AI Control Panel
            </CardTitle>
            <CardDescription>Manage AI-powered traffic optimization</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="ai-enabled">AI System Status</Label>
                <p className="text-sm text-muted-foreground">Enable or disable AI traffic management</p>
              </div>
              <Switch id="ai-enabled" checked={aiEnabled} onCheckedChange={setAiEnabled} />
            </div>
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="auto-control">Automatic Traffic Light Control</Label>
                <p className="text-sm text-muted-foreground">
                  Let AI control traffic lights automatically based on real-time analysis
                </p>
              </div>
              <Switch id="auto-control" checked={autoControl} onCheckedChange={setAutoControl} />
            </div>
            <div className="flex items-center gap-2 p-3 bg-primary/10 rounded-lg">
              <Activity className={`h-5 w-5 text-primary ${autoControl && aiEnabled ? "animate-pulse" : ""}`} />
              <span className="text-sm font-medium">
                {autoControl && aiEnabled
                  ? "AI Models Active: YOLO v8 (Vehicle Detection) • CNN (Classification) • LSTM (Prediction) • Auto-controlling traffic lights"
                  : "AI Models Active: YOLO v8 (Vehicle Detection) • CNN (Classification) • LSTM (Prediction)"}
              </span>
            </div>
          </CardContent>
        </Card>

        {/* Stats Overview */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Vehicles Detected</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">
                {vehicleData.cars + vehicleData.trucks + vehicleData.motorcycles + vehicleData.buses}
              </div>
              <p className="text-xs text-muted-foreground mt-1">Last 5 minutes</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Active Traffic Lights</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">
                {trafficLights.filter((tl) => tl.aiControlled).length}/{trafficLights.length}
              </div>
              <p className="text-xs text-muted-foreground mt-1">AI-controlled</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Congestion Zones</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-destructive">
                {congestionZones.filter((cz) => cz.level === "heavy").length}
              </div>
              <p className="text-xs text-muted-foreground mt-1">Heavy traffic areas</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Problem Reports</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-destructive">
                {problemReports.filter((r) => r.status === "pending").length}
              </div>
              <p className="text-xs text-muted-foreground mt-1">Pending review</p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Tabs */}
        <Tabs defaultValue="analytics" className="space-y-4" onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
            <TabsTrigger value="traffic-lights">Traffic Lights</TabsTrigger>
            <TabsTrigger value="cameras">Live Cameras</TabsTrigger>
            <TabsTrigger value="reports">Problem Reports</TabsTrigger>
            <TabsTrigger value="ai-logs">AI Decisions</TabsTrigger>
          </TabsList>

          <TabsContent value="analytics" className="space-y-4">
            <div className="grid lg:grid-cols-2 gap-4">
              <Card>
                <CardHeader>
                  <CardTitle>Traffic Flow (Last 12 Hours)</CardTitle>
                  <CardDescription>Real-time vehicle count and average speed</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={350}>
                    <AreaChart data={trafficFlowData} margin={{ top: 10, right: 30, left: 0, bottom: 20 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                      <XAxis
                        dataKey="time"
                        tick={{ fontSize: 12, fill: "hsl(var(--foreground))" }}
                        label={{ value: "Time", position: "insideBottom", offset: -10, fontSize: 14 }}
                      />
                      <YAxis
                        tick={{ fontSize: 12, fill: "hsl(var(--foreground))" }}
                        label={{ value: "Count / Speed", angle: -90, position: "insideLeft", fontSize: 14 }}
                      />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "hsl(var(--card))",
                          border: "1px solid hsl(var(--border))",
                          borderRadius: "8px",
                          fontSize: "14px",
                        }}
                      />
                      <Legend wrapperStyle={{ fontSize: "14px", paddingTop: "10px" }} />
                      <Area
                        type="monotone"
                        dataKey="vehicles"
                        stroke="hsl(var(--chart-1))"
                        fill="hsl(var(--chart-1))"
                        fillOpacity={0.6}
                        strokeWidth={2}
                        name="Vehicles"
                      />
                      <Area
                        type="monotone"
                        dataKey="avgSpeed"
                        stroke="hsl(var(--chart-2))"
                        fill="hsl(var(--chart-2))"
                        fillOpacity={0.6}
                        strokeWidth={2}
                        name="Avg Speed (km/h)"
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Vehicle Detection (YOLO v8)</CardTitle>
                  <CardDescription>AI-powered vehicle classification</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={350}>
                    <PieChart>
                      <Pie
                        data={vehicleChartData}
                        cx="50%"
                        cy="50%"
                        labelLine={true}
                        label={(entry) => `${entry.name}: ${entry.value}`}
                        outerRadius={100}
                        fill="#8884d8"
                        dataKey="value"
                        style={{ fontSize: "14px", fontWeight: "500" }}
                      >
                        {vehicleChartData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "hsl(var(--card))",
                          border: "1px solid hsl(var(--border))",
                          borderRadius: "8px",
                          fontSize: "14px",
                        }}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                  <div className="grid grid-cols-2 gap-4 mt-4">
                    <div className="flex items-center gap-2">
                      <Car className="h-4 w-4 text-chart-1" />
                      <span className="text-sm font-medium">Cars: {vehicleData.cars}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Truck className="h-4 w-4 text-chart-2" />
                      <span className="text-sm font-medium">Trucks: {vehicleData.trucks}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Bike className="h-4 w-4 text-chart-3" />
                      <span className="text-sm font-medium">Motorcycles: {vehicleData.motorcycles}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Bus className="h-4 w-4 text-chart-4" />
                      <span className="text-sm font-medium">Buses: {vehicleData.buses}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="lg:col-span-2">
                <CardHeader>
                  <CardTitle>Congestion Prediction (LSTM)</CardTitle>
                  <CardDescription>AI-predicted traffic congestion for next 6 hours</CardDescription>
                </CardHeader>
                <CardContent className="text-white">
                  <ResponsiveContainer width="100%" height={350}>
                    <BarChart data={predictions} margin={{ top: 10, right: 30, left: 0, bottom: 30 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                      <XAxis
                        dataKey="hour"
                        label={{ value: "Hours Ahead", position: "insideBottom", offset: -15, fontSize: 14 }}
                        tick={{ fontSize: 12, fill: "hsl(var(--foreground))" }}
                      />
                      <YAxis
                        label={{ value: "Probability (%)", angle: -90, position: "insideLeft", fontSize: 14 }}
                        tick={{ fontSize: 12, fill: "hsl(var(--foreground))" }}
                      />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "hsl(var(--card))",
                          border: "1px solid hsl(var(--border))",
                          borderRadius: "8px",
                          fontSize: "14px",
                        }}
                        formatter={(value: any) => [`${value}%`, "Congestion Probability"]}
                      />
                      <Legend wrapperStyle={{ fontSize: "14px", paddingTop: "10px" }} />
                      <Bar
                        dataKey="probability"
                        fill="hsl(var(--chart-2))"
                        radius={[8, 8, 0, 0]}
                        name="Probability %"
                      />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="traffic-lights" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Traffic Light Control</CardTitle>
                <CardDescription>Monitor and control AI-managed traffic signals (Manual & AI Control)</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {trafficLights.map((light) => {
                    const currentStatus = lightStatuses[light.id] || light.status
                    return (
                      <div key={light.id} className="flex flex-col gap-4 p-4 border border-border rounded-lg">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-4">
                            <div
                              className={`w-4 h-4 rounded-full ${currentStatus === "green" ? "bg-green-500" : currentStatus === "yellow" ? "bg-yellow-500" : "bg-red-500"}`}
                            />
                            <div>
                              <p className="font-semibold">{light.location}</p>
                              <p className="text-sm text-muted-foreground">
                                {light.id} • {light.lat.toFixed(4)}, {light.lng.toFixed(4)}
                              </p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="text-sm font-medium">{light.duration}s remaining</p>
                            <Badge variant={autoControl ? "default" : "secondary"}>
                              {autoControl ? "AI Controlled" : "Manual Mode"}
                            </Badge>
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          <span className="text-sm font-medium mr-2">Manual Control:</span>
                          <Button
                            size="sm"
                            variant={currentStatus === "green" ? "default" : "outline"}
                            className={currentStatus === "green" ? "bg-green-600 hover:bg-green-700" : ""}
                            onClick={() => handleManualLightControl(light.id, "green")}
                            disabled={autoControl}
                          >
                            Green
                          </Button>
                          <Button
                            size="sm"
                            variant={currentStatus === "yellow" ? "default" : "outline"}
                            className={currentStatus === "yellow" ? "bg-yellow-600 hover:bg-yellow-700" : ""}
                            onClick={() => handleManualLightControl(light.id, "yellow")}
                            disabled={autoControl}
                          >
                            Yellow
                          </Button>
                          <Button
                            size="sm"
                            variant={currentStatus === "red" ? "default" : "outline"}
                            className={currentStatus === "red" ? "bg-red-600 hover:bg-red-700" : ""}
                            onClick={() => handleManualLightControl(light.id, "red")}
                            disabled={autoControl}
                          >
                            Red
                          </Button>
                        </div>

                        {autoControl && (
                          <p className="text-xs text-muted-foreground">
                            Disable "Automatic Traffic Light Control" above to enable manual control
                          </p>
                        )}
                      </div>
                    )
                  })}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="cameras" className="space-y-4">
            <div className="flex justify-between items-center mb-4">
              <div>
                {liveCameraActive ? (
                  <Button variant="destructive" onClick={stopLiveCamera}>
                    <Camera className="mr-2 h-4 w-4" />
                    Stop Live Camera
                  </Button>
                ) : (
                  <Button onClick={startLiveCamera}>
                    <Camera className="mr-2 h-4 w-4" />
                    Start Live Camera for Data Collection
                  </Button>
                )}
              </div>
              <Dialog open={videoAnalysisOpen} onOpenChange={setVideoAnalysisOpen}>
                <DialogTrigger asChild>
                  <Button>
                    <FileVideo className="mr-2 h-4 w-4" />
                    Upload Video for AI Analysis
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>AI Video Analysis</DialogTitle>
                    <DialogDescription>
                      Upload a traffic video for analysis by YOLO v8, CNN, and LSTM models
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="video-upload">Select Video File</Label>
                      <input
                        id="video-upload"
                        type="file"
                        accept="video/*"
                        onChange={handleVideoUpload}
                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                      />
                      {uploadedVideo && (
                        <p className="text-sm text-muted-foreground">
                          Selected: {uploadedVideo.name} ({(uploadedVideo.size / 1024 / 1024).toFixed(2)} MB)
                        </p>
                      )}
                    </div>

                    <Button onClick={analyzeVideo} disabled={!uploadedVideo || analyzingVideo} className="w-full">
                      {analyzingVideo ? (
                        <>
                          <Activity className="mr-2 h-4 w-4 animate-spin" />
                          Analyzing with AI Models...
                        </>
                      ) : (
                        <>
                          <Zap className="mr-2 h-4 w-4" />
                          Analyze Video
                        </>
                      )}
                    </Button>

                    {videoAnalysisResults && (
                      <div className="space-y-4 p-4 border border-border rounded-lg bg-muted/50">
                        <div className="flex items-center justify-between">
                          <h3 className="font-semibold">AI Analysis Results</h3>
                          <Badge>Confidence: {(videoAnalysisResults.confidence * 100).toFixed(0)}%</Badge>
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <p className="text-sm text-muted-foreground">Total Vehicles Detected</p>
                            <p className="text-2xl font-bold">{videoAnalysisResults.totalVehicles}</p>
                          </div>
                          <div>
                            <p className="text-sm text-muted-foreground">Traffic Flow</p>
                            <p className="text-2xl font-bold">{videoAnalysisResults.trafficFlow}</p>
                          </div>
                          <div>
                            <p className="text-sm text-muted-foreground">Avg Speed</p>
                            <p className="text-2xl font-bold">{videoAnalysisResults.avgSpeed} km/h</p>
                          </div>
                          <div>
                            <p className="text-sm text-muted-foreground">Detection Confidence</p>
                            <p className="text-2xl font-bold">{videoAnalysisResults.avgConfidence.toFixed(0)}%</p>
                          </div>
                        </div>

                        <div>
                          <p className="text-sm font-medium mb-2">Vehicle Breakdown (YOLO v8 + CNN):</p>
                          <div className="grid grid-cols-2 gap-2 text-sm">
                            <div className="flex items-center gap-2">
                              <Car className="h-4 w-4" />
                              Cars: {videoAnalysisResults.vehicleBreakdown.cars}
                            </div>
                            <div className="flex items-center gap-2">
                              <Truck className="h-4 w-4" />
                              Trucks: {videoAnalysisResults.vehicleBreakdown.trucks}
                            </div>
                            <div className="flex items-center gap-2">
                              <Bike className="h-4 w-4" />
                              Motorcycles: {videoAnalysisResults.vehicleBreakdown.motorcycles}
                            </div>
                            <div className="flex items-center gap-2">
                              <Bus className="h-4 w-4" />
                              Buses: {videoAnalysisResults.vehicleBreakdown.buses}
                            </div>
                          </div>
                        </div>

                        <div className="space-y-2">
                          <div className="p-3 bg-primary/10 rounded-lg">
                            <p className="text-sm font-medium mb-1">AI Decision:</p>
                            <p className="text-sm">{videoAnalysisResults.aiDecision}</p>
                          </div>
                          <div className="p-3 bg-chart-2/10 rounded-lg">
                            <p className="text-sm font-medium mb-1">LSTM Prediction:</p>
                            <p className="text-sm">{videoAnalysisResults.prediction}</p>
                          </div>
                        </div>

                        <div className="flex items-center justify-between text-xs text-muted-foreground">
                          <span>Models: {videoAnalysisResults.modelsUsed.join(", ")}</span>
                          <span>Processing Time: {videoAnalysisResults.processingTime}</span>
                        </div>
                      </div>
                    )}
                  </div>
                </DialogContent>
              </Dialog>
            </div>

            {liveCameraActive && (
              <Card className="mb-4 border-primary">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Camera className="h-5 w-5 text-primary animate-pulse" />
                    Live Camera Feed - AI Data Collection with Object Detection
                  </CardTitle>
                  <CardDescription>
                    Real-time traffic analysis using YOLO v8 with bounding box visualization
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid lg:grid-cols-2 gap-4">
                    <div className="aspect-video bg-muted rounded-lg overflow-hidden relative">
                      <video ref={videoPlayerRef} autoPlay playsInline muted className="w-full h-full object-cover" />

                      {liveCameraAnalysis && liveCameraAnalysis.boundingBoxes && (
                        <svg className="absolute inset-0 w-full h-full pointer-events-none" style={{ zIndex: 10 }}>
                          {liveCameraAnalysis.boundingBoxes.map((box: any, index: number) => {
                            const color =
                              box.type === "car"
                                ? "#22c55e"
                                : box.type === "truck"
                                  ? "#f97316"
                                  : box.type === "motorcycle"
                                    ? "#eab308"
                                    : "#3b82f6"

                            return (
                              <g key={index}>
                                <rect
                                  x={`${box.x}%`}
                                  y={`${box.y}%`}
                                  width={`${box.width}%`}
                                  height={`${box.height}%`}
                                  fill="none"
                                  stroke={color}
                                  strokeWidth="2"
                                  opacity="0.8"
                                />
                                <text
                                  x={`${box.x + 1}%`}
                                  y={`${box.y + 2}%`}
                                  fill={color}
                                  fontSize="12"
                                  fontWeight="bold"
                                  style={{ textShadow: "0 0 3px black" }}
                                >
                                  {box.type} {(box.confidence * 100).toFixed(0)}%
                                </text>
                              </g>
                            )
                          })}
                        </svg>
                      )}

                      <div className="absolute top-2 left-2 bg-red-600 text-white text-xs px-2 py-1 rounded flex items-center gap-1">
                        <div className="w-2 h-2 bg-white rounded-full animate-pulse" />
                        LIVE - AI ANALYZING
                      </div>
                      <div className="absolute bottom-2 left-2 bg-black/70 text-white text-xs px-2 py-1 rounded">
                        YOLO v8 Object Detection Active
                      </div>
                      {liveCameraAnalysis && (
                        <div className="absolute bottom-2 right-2 bg-black/70 text-white text-xs px-2 py-1 rounded">
                          {liveCameraAnalysis.boundingBoxes?.length || 0} objects detected
                        </div>
                      )}
                    </div>

                    {liveCameraAnalysis && (
                      <div className="space-y-4">
                        <div className="p-4 border border-border rounded-lg bg-muted/50">
                          <div className="flex items-center justify-between mb-3">
                            <h3 className="font-semibold">Real-Time AI Analysis</h3>
                            <Badge>Updated: {liveCameraAnalysis.timestamp}</Badge>
                          </div>

                          <div className="grid grid-cols-2 gap-3 mb-4">
                            <div>
                              <p className="text-sm text-muted-foreground">Total Vehicles</p>
                              <p className="text-2xl font-bold">{liveCameraAnalysis.totalVehicles}</p>
                            </div>
                            <div>
                              <p className="text-sm text-muted-foreground">Traffic Flow</p>
                              <p className="text-2xl font-bold">{liveCameraAnalysis.trafficFlow}</p>
                            </div>
                            <div>
                              <p className="text-sm text-muted-foreground">Avg Speed</p>
                              <p className="text-2xl font-bold">{liveCameraAnalysis.avgSpeed} km/h</p>
                            </div>
                            <div>
                              <p className="text-sm text-muted-foreground">Confidence</p>
                              <p className="text-2xl font-bold">{liveCameraAnalysis.avgConfidence.toFixed(0)}%</p>
                            </div>
                          </div>

                          <div className="space-y-2 mb-4">
                            <p className="text-sm font-medium">Vehicle Breakdown:</p>
                            <div className="grid grid-cols-2 gap-2 text-sm">
                              <div className="flex items-center gap-2">
                                <Car className="h-4 w-4" />
                                Cars: {liveCameraAnalysis.vehicleBreakdown.cars}
                              </div>
                              <div className="flex items-center gap-2">
                                <Truck className="h-4 w-4" />
                                Trucks: {liveCameraAnalysis.vehicleBreakdown.trucks}
                              </div>
                              <div className="flex items-center gap-2">
                                <Bike className="h-4 w-4" />
                                Motorcycles: {liveCameraAnalysis.vehicleBreakdown.motorcycles}
                              </div>
                              <div className="flex items-center gap-2">
                                <Bus className="h-4 w-4" />
                                Buses: {liveCameraAnalysis.vehicleBreakdown.buses}
                              </div>
                            </div>
                          </div>

                          <div className="space-y-2">
                            <div className="p-3 bg-primary/10 rounded-lg">
                              <p className="text-sm font-medium mb-1">AI Decision:</p>
                              <p className="text-sm">{liveCameraAnalysis.aiDecision}</p>
                            </div>
                            <div className="p-3 bg-chart-2/10 rounded-lg">
                              <p className="text-sm font-medium mb-1">LSTM Prediction:</p>
                              <p className="text-sm">{liveCameraAnalysis.prediction}</p>
                            </div>
                          </div>

                          <div className="mt-4">
                            <p className="text-sm font-medium mb-2">Additional AI Insights:</p>
                            <div className="grid grid-cols-2 gap-3 text-xs">
                              <div className="flex items-center gap-1">
                                <Activity className="h-3 w-3 text-primary" />
                                Time Context: <span className="font-semibold">{liveCameraAnalysis.timeContext}</span>
                              </div>
                              <div className="flex items-center gap-1">
                                <TrendingUp className="h-3 w-3 text-chart-3" />
                                Recommended Action:{" "}
                                <span className="font-semibold">{liveCameraAnalysis.recommendedAction}</span>
                              </div>
                              <div className="flex items-center gap-1">
                                <AlertTriangle className="h-3 w-3 text-destructive" />
                                Congestion Risk:{" "}
                                <span className="font-semibold">{liveCameraAnalysis.congestionRisk}</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            )}

            <div className="grid md:grid-cols-2 gap-4">
              {congestionZones.map((zone, index) => (
                <Card key={zone.id}>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Camera className="h-5 w-5" />
                      {zone.location}
                    </CardTitle>
                    <CardDescription>
                      <Badge
                        variant={
                          zone.level === "heavy" ? "destructive" : zone.level === "moderate" ? "default" : "secondary"
                        }
                      >
                        {zone.level.toUpperCase()}
                      </Badge>
                      <span className="ml-2 text-xs">AI Confidence: {(zone.confidence * 100).toFixed(0)}%</span>
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="aspect-video bg-muted rounded-lg overflow-hidden mb-4 relative">
                      <video
                        autoPlay
                        loop
                        muted
                        playsInline
                        className="w-full h-full object-cover"
                        src={`/placeholder.svg?height=360&width=640&query=traffic+camera+feed+${index + 1}`}
                      >
                        <div className="absolute inset-0 flex items-center justify-center bg-muted">
                          <div className="text-center">
                            <Camera className="h-12 w-12 text-muted-foreground mx-auto mb-2" />
                            <p className="text-sm text-muted-foreground">Live Camera Feed</p>
                            <p className="text-xs text-muted-foreground">{zone.id}</p>
                          </div>
                        </div>
                      </video>
                      <div className="absolute top-2 left-2 bg-red-600 text-white text-xs px-2 py-1 rounded flex items-center gap-1">
                        <div className="w-2 h-2 bg-white rounded-full animate-pulse" />
                        LIVE
                      </div>
                      <div className="absolute bottom-2 left-2 bg-black/70 text-white text-xs px-2 py-1 rounded">
                        YOLO v8 Active
                      </div>
                    </div>
                    <div className="grid grid-cols-3 gap-4 text-sm">
                      <div>
                        <p className="text-muted-foreground">Vehicles</p>
                        <p className="font-semibold">{zone.vehicleCount}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Avg Speed</p>
                        <p className="font-semibold">{zone.avgSpeed} km/h</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Duration</p>
                        <p className="font-semibold">{zone.predictedDuration} min</p>
                      </div>
                    </div>
                    <div className="mt-4 p-3 bg-muted rounded-lg text-xs">
                      <p className="font-medium mb-1">AI Analysis:</p>
                      <p className="text-muted-foreground">
                        {zone.level === "heavy"
                          ? "Heavy traffic detected. Recommend extending green light duration."
                          : zone.level === "moderate"
                            ? "Moderate traffic flow. Current timing optimal."
                            : "Free flowing traffic. Consider reducing green light duration."}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="reports" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>User-Reported Problems</CardTitle>
                <CardDescription>Review and manage road problem reports from users</CardDescription>
              </CardHeader>
              <CardContent>
                {problemReports.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <AlertTriangle className="h-12 w-12 mx-auto mb-2 opacity-50" />
                    <p>No problem reports yet</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {problemReports.map((report) => (
                      <div key={report.id} className="p-4 border border-border rounded-lg space-y-3">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              <Badge
                                variant={
                                  report.status === "pending"
                                    ? "destructive"
                                    : report.status === "resolved"
                                      ? "default"
                                      : "secondary"
                                }
                              >
                                {report.status.toUpperCase()}
                              </Badge>
                              <span className="text-xs text-muted-foreground">
                                {new Date(report.timestamp).toLocaleString()}
                              </span>
                            </div>
                            <p className="font-semibold flex items-center gap-2">
                              <MapPin className="h-4 w-4" />
                              {report.location}
                            </p>
                            <p className="text-sm text-muted-foreground mt-2">{report.description}</p>
                          </div>
                        </div>

                        {report.files && report.files.length > 0 && (
                          <div className="space-y-2">
                            <p className="text-sm font-medium">Evidence Files:</p>
                            <div className="flex flex-wrap gap-2">
                              {report.files.map((file: any, index: number) => (
                                <div key={index} className="flex items-center gap-2 text-xs p-2 bg-muted rounded">
                                  {file.type.startsWith("video") ? (
                                    <FileVideo className="h-4 w-4" />
                                  ) : (
                                    <ImageIcon className="h-4 w-4" />
                                  )}
                                  <span>{file.name}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}

                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleReportStatusUpdate(report.id, "in-progress")}
                            disabled={report.status !== "pending"}
                          >
                            Mark In Progress
                          </Button>
                          <Button
                            size="sm"
                            onClick={() => handleReportStatusUpdate(report.id, "resolved")}
                            disabled={report.status === "resolved"}
                          >
                            Mark Resolved
                          </Button>
                          <Button size="sm" variant="secondary" onClick={() => handleSendReportAlert(report)}>
                            <Send className="mr-2 h-4 w-4" />
                            Alert Users
                          </Button>
                          <Button size="sm" variant="destructive" onClick={() => handleDeleteReport(report.id)}>
                            Delete
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="ai-logs" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>AI Decision Log</CardTitle>
                <CardDescription>Recent decisions made by the AI traffic management system</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {aiDecisions.map((decision) => (
                    <div key={decision.id} className="flex gap-4 p-4 border border-border rounded-lg">
                      <div className="flex-shrink-0">
                        {decision.type === "traffic_light" ? (
                          <Zap className="h-5 w-5 text-primary" />
                        ) : decision.type === "congestion_alert" ? (
                          <AlertTriangle className="h-5 w-5 text-destructive" />
                        ) : (
                          <TrendingUp className="h-5 w-5 text-chart-3" />
                        )}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-1">
                          <Badge variant="outline">{decision.type.replace("_", " ").toUpperCase()}</Badge>
                          <span className="text-xs text-muted-foreground">
                            {decision.timestamp.toLocaleTimeString()}
                          </span>
                        </div>
                        <p className="text-sm mb-1">{decision.description}</p>
                        <div className="flex items-center gap-4 text-xs text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <MapPin className="h-3 w-3" />
                            {decision.location}
                          </span>
                          <span>Confidence: {(decision.confidence * 100).toFixed(0)}%</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}
